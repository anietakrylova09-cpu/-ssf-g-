# OSINT Platform

## Overview

This is a comprehensive OSINT (Open Source Intelligence) platform that provides various investigative tools and services. The application combines AI-powered analysis with traditional OSINT techniques, offering features like phone number validation, person search, social media analysis, metadata extraction, geolocation tracking, and custom software integration. The platform is built as a full-stack web application with React frontend and Express backend, with optional Electron wrapper for desktop deployment.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Comprehensive Radix UI primitives with custom theming
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Data Storage**: In-memory storage implementation (can be extended to PostgreSQL)
- **API Design**: RESTful endpoints with JSON responses
- **Error Handling**: Centralized error middleware with proper HTTP status codes

### Core Services
- **AI Service**: Integrates with Grok (xAI) and DeepSeek APIs for intelligent OSINT query processing
- **Phone Service**: Phone number validation with carrier and region detection
- **OSINT Service**: Person search capabilities across multiple sources
- **Softs Service**: Custom software integration and execution platform

### Database Schema
- **Users**: Authentication and user management
- **OSINT Searches**: Search queries, results, and status tracking
- **AI Conversations**: Chat history and message persistence
- **Phone Validations**: Phone validation results and metadata

### Authentication & Authorization
- Currently implements basic user model structure
- Session-based authentication preparation with connect-pg-simple
- User identification for search history and personalization

### Development Environment
- **Development Server**: Vite dev server with HMR
- **API Logging**: Request/response logging with duration tracking
- **Error Overlay**: Runtime error modal for development
- **Type Safety**: Full TypeScript coverage across frontend and backend

### Desktop Application
- **Electron Integration**: Cross-platform desktop app capability
- **Build System**: electron-builder for packaging and distribution
- **Auto-updater**: NSIS installer for Windows with update management
- **Asset Management**: Icon and branding assets included

### UI/UX Design
- **Dark Theme**: Default dark mode with customizable color schemes
- **Responsive Design**: Mobile-first approach with breakpoint management
- **Component System**: Modular UI components with consistent styling
- **Theme System**: Multiple color themes (pink, blue, green, purple)
- **Accessibility**: Radix UI primitives ensure accessibility compliance

## External Dependencies

### AI Services
- **Grok (xAI)**: Primary AI model for OSINT query analysis
- **DeepSeek**: Secondary AI model for enhanced analysis capabilities

### Database
- **Neon Database**: Serverless PostgreSQL provider (@neondatabase/serverless)
- **Drizzle Kit**: Database migrations and schema management

### UI Framework
- **Radix UI**: Comprehensive primitive components for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the entire codebase
- **ESBuild**: Fast JavaScript bundler for production builds

### Monitoring & Analytics
- **Replit Plugins**: Cartographer for code mapping and dev banner for development
- **Runtime Error Handling**: Custom error overlay for development

### Fonts & Assets
- **Google Fonts**: Inter, JetBrains Mono for typography
- **Font Awesome**: Icon library integration planned

### Build & Deployment
- **Concurrently**: Parallel script execution for development
- **Electron Builder**: Desktop application packaging
- **PostCSS**: CSS processing with autoprefixer