interface PhoneValidationResult {
  phoneNumber: string;
  isValid: boolean;
  country?: string;
  region?: string;
  operator?: string;
  phoneType?: string;
  socialProfiles?: {
    whatsapp?: boolean;
    telegram?: boolean;
    viber?: boolean;
  };
}

class PhoneService {
  async validatePhoneNumber(phoneNumber: string, sources: any): Promise<PhoneValidationResult> {
    // Clean the phone number
    const cleanedNumber = this.cleanPhoneNumber(phoneNumber);
    
    // Basic validation
    const validation = this.basicValidation(cleanedNumber);
    
    if (!validation.isValid) {
      return validation;
    }

    // Enhanced validation with region/operator detection
    const enhancedInfo = this.getEnhancedInfo(cleanedNumber);
    
    // Check social media presence if requested
    const socialProfiles = await this.checkSocialProfiles(cleanedNumber, sources);

    return {
      ...validation,
      ...enhancedInfo,
      socialProfiles,
    };
  }

  private cleanPhoneNumber(phoneNumber: string): string {
    // Remove all non-digit characters except +
    return phoneNumber.replace(/[^\d+]/g, '');
  }

  private basicValidation(phoneNumber: string): PhoneValidationResult {
    // Basic phone number validation
    const phoneRegex = /^\+?[1-9]\d{7,14}$/;
    
    return {
      phoneNumber,
      isValid: phoneRegex.test(phoneNumber),
    };
  }

  private getEnhancedInfo(phoneNumber: string): Partial<PhoneValidationResult> {
    // Russian phone number analysis
    if (phoneNumber.startsWith('+7') || phoneNumber.startsWith('7')) {
      const number = phoneNumber.replace(/^\+?7/, '');
      
      // Moscow and region codes
      if (number.startsWith('495') || number.startsWith('499')) {
        return {
          country: 'Россия (+7)',
          region: 'Москва',
          operator: this.getOperatorByPrefix(number.substring(0, 3)),
          phoneType: 'Городской',
        };
      }
      
      // Mobile operators
      if (number.startsWith('9')) {
        const prefix = number.substring(0, 3);
        return {
          country: 'Россия (+7)',
          region: this.getRegionByMobilePrefix(prefix),
          operator: this.getMobileOperator(prefix),
          phoneType: 'Мобильный',
        };
      }
    }

    return {
      country: 'Неизвестно',
      region: 'Неизвестно',
      operator: 'Неизвестно',
      phoneType: 'Неизвестно',
    };
  }

  private getOperatorByPrefix(prefix: string): string {
    const operators: Record<string, string> = {
      '495': 'МГТС',
      '499': 'МГТС',
    };
    
    return operators[prefix] || 'Неизвестно';
  }

  private getMobileOperator(prefix: string): string {
    const operators: Record<string, string> = {
      '999': 'МТС',
      '998': 'МТС', 
      '997': 'МТС',
      '996': 'МТС',
      '995': 'МТС',
      '994': 'МТС',
      '993': 'МТС',
      '992': 'МТС',
      '991': 'МТС',
      '985': 'МТС',
      '984': 'МТС',
      '983': 'МТС',
      '982': 'МТС',
      '981': 'МТС',
      '980': 'МТС',
      '977': 'МТС',
      '976': 'МТС',
      '975': 'МТС',
      '974': 'МТС',
      '973': 'МТС',
      '972': 'МТС',
      '971': 'МТС',
      '970': 'МТС',
      '969': 'МТС',
      '916': 'МТС',
      '915': 'МТС',
      '903': 'Билайн',
      '905': 'Билайн',
      '906': 'Билайн',
      '909': 'Билайн',
      '951': 'Билайн',
      '953': 'Билайн',
      '960': 'Билайн',
      '961': 'Билайн',
      '962': 'Билайн',
      '963': 'Билайн',
      '964': 'Билайн',
      '965': 'Билайн',
      '966': 'Билайн',
      '967': 'Билайн',
      '968': 'Билайн',
      '900': 'МегаФон',
      '902': 'МегаФон',
      '904': 'МегаФон',
      '908': 'МегаФон',
      '920': 'МегаФон',
      '921': 'МегаФон',
      '922': 'МегаФон',
      '923': 'МегаФон',
      '924': 'МегаФон',
      '925': 'МегаФон',
      '926': 'МегаФон',
      '927': 'МегаФон',
      '928': 'МегаФон',
      '929': 'МегаФон',
      '930': 'МегаФон',
      '931': 'МегаФон',
      '932': 'МегаФон',
      '933': 'МегаФон',
      '934': 'МегаФон',
      '936': 'МегаФон',
      '937': 'МегаФон',
      '938': 'МегаФон',
      '939': 'МегаФон',
    };
    
    return operators[prefix] || 'Неизвестно';
  }

  private getRegionByMobilePrefix(prefix: string): string {
    // Simplified region detection - in real implementation this would be more complex
    const moscowPrefixes = ['999', '995', '926', '903'];
    const spbPrefixes = ['921', '922', '905'];
    
    if (moscowPrefixes.includes(prefix)) {
      return 'Москва и область';
    }
    
    if (spbPrefixes.includes(prefix)) {
      return 'Санкт-Петербург';
    }
    
    return 'Россия (регион не определен)';
  }

  private async checkSocialProfiles(phoneNumber: string, sources: any): Promise<PhoneValidationResult['socialProfiles']> {
    const profiles: PhoneValidationResult['socialProfiles'] = {};

    // Simulate social media checks
    if (sources.telegram) {
      profiles.telegram = Math.random() > 0.5; // Simulate 50% chance
    }

    if (sources.whatsapp) {
      profiles.whatsapp = Math.random() > 0.3; // Simulate 70% chance
    }

    if (sources.viber) {
      profiles.viber = Math.random() > 0.7; // Simulate 30% chance
    }

    return profiles;
  }
}

export const phoneService = new PhoneService();
