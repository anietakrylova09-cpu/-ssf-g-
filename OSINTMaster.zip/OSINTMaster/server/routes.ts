import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiService } from "./services/ai-service";
import { phoneService } from "./services/phone-service";
import { osintService } from "./services/osint-service";
import { softsService } from "./services/softs-service";
import { insertOsintSearchSchema, insertPhoneValidationSchema, aiChatRequestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // AI Chat endpoints
  app.get("/api/ai/health", async (req, res) => {
    try {
      const healthStatuses = await aiService.checkHealthStatus();
      res.json(healthStatuses);
    } catch (error) {
      console.error("AI Health Check Error:", error);
      res.status(500).json({ error: "Ошибка при проверке статуса AI" });
    }
  });

  app.post("/api/ai/chat", async (req, res) => {
    try {
      // Validate request body with Zod
      const validationResult = aiChatRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Некорректные данные запроса", 
          details: validationResult.error.issues 
        });
      }

      const { message } = validationResult.data;
      const result = await aiService.processOsintQuery(message);
      res.json(result);
    } catch (error) {
      console.error("AI Chat Error:", error);
      
      const errorMessage = error instanceof Error ? error.message : "Ошибка при обработке запроса AI";
      const statusCode = errorMessage.includes("API ключи") || errorMessage.includes("не доступен") ? 503 : 500;
      
      res.status(statusCode).json({ error: errorMessage });
    }
  });

  // Phone validation endpoints
  app.post("/api/phone/validate", async (req, res) => {
    try {
      const { phoneNumber, sources } = req.body;
      
      if (!phoneNumber?.trim()) {
        return res.status(400).json({ error: "Номер телефона обязателен" });
      }

      const result = await phoneService.validatePhoneNumber(phoneNumber, sources || {});
      
      // Save validation result
      try {
        await storage.createPhoneValidation({
          phoneNumber: result.phoneNumber,
          isValid: result.isValid,
          country: result.country || null,
          region: result.region || null,
          operator: result.operator || null,
          phoneType: result.phoneType || null,
          socialProfiles: result.socialProfiles || null,
        });
      } catch (storageError) {
        console.warn("Failed to save phone validation:", storageError);
      }

      res.json(result);
    } catch (error) {
      console.error("Phone Validation Error:", error);
      res.status(500).json({ error: "Ошибка при валидации номера" });
    }
  });

  // Person search endpoints
  app.post("/api/person/search", async (req, res) => {
    try {
      const searchParams = req.body;
      
      if (!searchParams.fullName?.trim()) {
        return res.status(400).json({ error: "ФИО обязательно для поиска" });
      }

      const result = await osintService.searchPerson(searchParams);
      
      if (!result) {
        return res.status(404).json({ error: "Информация не найдена" });
      }

      // Save search result
      try {
        await storage.createOsintSearch({
          searchType: "person",
          query: JSON.stringify(searchParams),
          results: result,
          status: "completed",
        });
      } catch (storageError) {
        console.warn("Failed to save person search:", storageError);
      }

      res.json(result);
    } catch (error) {
      console.error("Person Search Error:", error);
      res.status(500).json({ error: "Ошибка при поиске личности" });
    }
  });

  // Social media analysis endpoints
  app.post("/api/social/analyze", async (req, res) => {
    try {
      const { platform, username } = req.body;
      
      if (!platform || !username) {
        return res.status(400).json({ error: "Платформа и username обязательны" });
      }

      const result = await osintService.analyzeSocialProfile(platform, username);
      res.json(result);
    } catch (error) {
      console.error("Social Analysis Error:", error);
      res.status(500).json({ error: "Ошибка при анализе профиля" });
    }
  });

  // Metadata analysis endpoints
  app.post("/api/metadata/analyze", async (req, res) => {
    try {
      // In a real implementation, you'd handle file uploads here
      const { fileName, fileData } = req.body;
      
      if (!fileName || !fileData) {
        return res.status(400).json({ error: "Файл обязателен для анализа" });
      }

      const fileBuffer = Buffer.from(fileData, 'base64');
      const result = await osintService.analyzeMetadata(fileBuffer, fileName);
      res.json(result);
    } catch (error) {
      console.error("Metadata Analysis Error:", error);
      res.status(500).json({ error: "Ошибка при анализе метаданных" });
    }
  });

  // Geolocation endpoints
  app.post("/api/geo/locate", async (req, res) => {
    try {
      const { coordinates, address } = req.body;
      
      if (!coordinates && !address) {
        return res.status(400).json({ error: "Координаты или адрес обязательны" });
      }

      const result = await osintService.geoLocate(coordinates, address);
      res.json(result);
    } catch (error) {
      console.error("Geolocation Error:", error);
      res.status(500).json({ error: "Ошибка при геолокации" });
    }
  });

  // Softs execution endpoints
  app.post("/api/softs/execute", async (req, res) => {
    try {
      const { software, query, type } = req.body;
      
      if (!software || !query?.trim()) {
        return res.status(400).json({ error: "Программа и запрос обязательны" });
      }

      const result = await softsService.executeSoftware(software, query, type);
      res.json(result);
    } catch (error) {
      console.error("Softs Execution Error:", error);
      res.status(500).json({ error: "Ошибка при выполнении программы" });
    }
  });

  app.post("/api/softs/upload", async (req, res) => {
    try {
      // In a real implementation, you'd handle file uploads with multer
      const { file, config } = req.body;
      
      if (!file || !config) {
        return res.status(400).json({ error: "Файл и конфигурация обязательны" });
      }

      // Simulate file upload for demo
      const mockFile = {
        originalname: config.name + ".exe",
        buffer: Buffer.from("mock file content")
      };

      const result = await softsService.uploadSoftware(mockFile, JSON.parse(config));
      res.json(result);
    } catch (error) {
      console.error("Software Upload Error:", error);
      res.status(500).json({ error: "Ошибка при загрузке программы" });
    }
  });

  app.get("/api/softs/list", async (req, res) => {
    try {
      const software = softsService.getUploadedSoftware();
      res.json(software);
    } catch (error) {
      console.error("Software List Error:", error);
      res.status(500).json({ error: "Ошибка при получении списка программ" });
    }
  });

  app.delete("/api/softs/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = softsService.deleteSoftware(id);
      
      if (success) {
        res.json({ message: "Программа удалена" });
      } else {
        res.status(404).json({ error: "Программа не найдена" });
      }
    } catch (error) {
      console.error("Software Delete Error:", error);
      res.status(500).json({ error: "Ошибка при удалении программы" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      services: {
        ai: process.env.XAI_API_KEY ? "configured" : "not_configured",
        deepseek: process.env.DEEPSEEK_API_KEY ? "configured" : "not_configured"
      }
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
