import { useState } from "react";

export function SocialAnalyzer() {
  const [platform, setPlatform] = useState("vk");
  const [username, setUsername] = useState("");

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Анализ социальных сетей</h2>
          <p className="text-muted-foreground">
            Анализ публичных профилей в социальных сетях и поиск связанных аккаунтов
          </p>
        </header>

        <div className="gradient-bg rounded-xl p-6 border border-border">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Платформа</label>
              <select
                data-testid="platform-select"
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
              >
                <option value="vk">VKontakte</option>
                <option value="telegram">Telegram</option>
                <option value="instagram">Instagram</option>
                <option value="facebook">Facebook</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Username/URL</label>
              <input
                data-testid="username-input"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="username или ссылка на профиль"
                className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>

          <button
            data-testid="analyze-btn"
            className="mt-6 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors"
          >
            <i className="fas fa-users mr-2"></i>
            Анализировать профиль
          </button>
        </div>

        <div className="mt-8 text-center text-muted-foreground">
          <i className="fas fa-users text-4xl mb-4 opacity-50"></i>
          <p>Введите данные профиля для анализа</p>
        </div>
      </div>
    </section>
  );
}
