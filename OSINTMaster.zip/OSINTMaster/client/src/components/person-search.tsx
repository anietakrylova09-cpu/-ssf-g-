import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface PersonSearchParams {
  fullName?: string;
  birthDate?: string;
  passportNumber?: string;
  region?: string;
  sources: {
    socialNetworks: boolean;
    openBases: boolean;
    telegramSearch: boolean;
  };
}

interface PersonResult {
  fullName: string;
  age: number;
  location: string;
  confidence: number;
  contacts?: {
    phone?: string;
    email?: string;
    address?: string;
  };
  socialProfiles?: Array<{
    platform: string;
    url: string;
    username: string;
    friends?: number;
    lastActive?: string;
  }>;
  additionalInfo?: {
    work?: string;
    position?: string;
    education?: string;
    warnings?: string[];
  };
}

export function PersonSearch() {
  const [searchParams, setSearchParams] = useState<PersonSearchParams>({
    sources: {
      socialNetworks: true,
      openBases: true,
      telegramSearch: false,
    }
  });
  const [searchResult, setSearchResult] = useState<PersonResult | null>(null);

  const searchPersonMutation = useMutation({
    mutationFn: async (params: PersonSearchParams) => {
      const response = await apiRequest("POST", "/api/person/search", params);
      return response.json();
    },
    onSuccess: (data) => {
      setSearchResult(data);
    },
  });

  const handleSearch = () => {
    if (!searchParams.fullName?.trim()) return;
    searchPersonMutation.mutate(searchParams);
  };

  const updateSearchParam = (key: keyof PersonSearchParams, value: any) => {
    setSearchParams(prev => ({ ...prev, [key]: value }));
  };

  const updateSource = (source: keyof PersonSearchParams['sources'], value: boolean) => {
    setSearchParams(prev => ({
      ...prev,
      sources: { ...prev.sources, [source]: value }
    }));
  };

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Поиск личности</h2>
          <p className="text-muted-foreground">
            Комплексный поиск информации о человеке по различным параметрам
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Search Form */}
          <div className="lg:col-span-1">
            <div className="gradient-bg rounded-xl p-6 border border-border sticky top-6">
              <h3 className="text-xl font-semibold mb-6">Параметры поиска</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">ФИО</label>
                  <input
                    data-testid="fullname-input"
                    type="text"
                    value={searchParams.fullName || ""}
                    onChange={(e) => updateSearchParam("fullName", e.target.value)}
                    placeholder="Иванов Иван Иванович"
                    className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Дата рождения</label>
                  <input
                    data-testid="birthdate-input"
                    type="date"
                    value={searchParams.birthDate || ""}
                    onChange={(e) => updateSearchParam("birthDate", e.target.value)}
                    className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Номер паспорта</label>
                  <input
                    data-testid="passport-input"
                    type="text"
                    value={searchParams.passportNumber || ""}
                    onChange={(e) => updateSearchParam("passportNumber", e.target.value)}
                    placeholder="1234 567890"
                    className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Регион</label>
                  <select
                    data-testid="region-select"
                    value={searchParams.region || ""}
                    onChange={(e) => updateSearchParam("region", e.target.value)}
                    className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value="">Все регионы</option>
                    <option value="moscow">Москва</option>
                    <option value="spb">Санкт-Петербург</option>
                    <option value="moscow-region">Московская область</option>
                  </select>
                </div>

                <div className="border-t border-border pt-4">
                  <h4 className="font-medium mb-3">Источники данных</h4>
                  <div className="space-y-2">
                    {Object.entries(searchParams.sources).map(([key, value]) => (
                      <label key={key} className="flex items-center space-x-2">
                        <input
                          data-testid={`source-${key}`}
                          type="checkbox"
                          checked={value}
                          onChange={(e) => updateSource(key as keyof PersonSearchParams['sources'], e.target.checked)}
                          className="rounded border-border"
                        />
                        <span className="text-sm">
                          {key === 'socialNetworks' && 'Социальные сети'}
                          {key === 'openBases' && 'Открытые базы'}
                          {key === 'telegramSearch' && 'Telegram поиск'}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  data-testid="search-btn"
                  onClick={handleSearch}
                  disabled={!searchParams.fullName?.trim() || searchPersonMutation.isPending}
                  className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors disabled:opacity-50"
                >
                  {searchPersonMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Поиск...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-search mr-2"></i>
                      Начать поиск
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="lg:col-span-2 space-y-6">
            {!searchResult && !searchPersonMutation.isPending && (
              <div className="text-center text-muted-foreground py-12">
                <i className="fas fa-user-secret text-6xl mb-4 opacity-50"></i>
                <p className="text-xl">Введите данные для поиска личности</p>
              </div>
            )}

            {searchPersonMutation.isPending && (
              <div className="text-center py-12">
                <i className="fas fa-spinner fa-spin text-6xl text-primary mb-4"></i>
                <p className="text-xl text-muted-foreground">Выполняется поиск...</p>
              </div>
            )}

            {searchResult && (
              <div data-testid="search-results">
                {/* Profile Card */}
                <div className="gradient-bg rounded-xl p-6 border border-border">
                  <div className="flex items-start space-x-4 mb-6">
                    <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
                      <i className="fas fa-user text-2xl text-muted-foreground"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold">{searchResult.fullName}</h3>
                      <p className="text-muted-foreground">{searchResult.age} лет, {searchResult.location}</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm">
                        <span className="inline-flex items-center px-2 py-1 rounded-md bg-green-100 text-green-800">
                          <span className="w-2 h-2 bg-green-400 rounded-full mr-1.5"></span>
                          Найден
                        </span>
                        <span className="text-muted-foreground">
                          Достоверность: {searchResult.confidence}%
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="code-block rounded-lg p-4">
                      <h4 className="text-blue-400 font-medium mb-2">📋 Основная информация</h4>
                      <div className="space-y-1 text-sm font-mono">
                        <div>ФИО: <span className="text-white">{searchResult.fullName}</span></div>
                        <div>Возраст: <span className="text-green-400">{searchResult.age} лет</span></div>
                        <div>Местоположение: <span className="text-yellow-400">{searchResult.location}</span></div>
                      </div>
                    </div>

                    {searchResult.contacts && (
                      <div className="code-block rounded-lg p-4">
                        <h4 className="text-purple-400 font-medium mb-2">📱 Контакты</h4>
                        <div className="space-y-1 text-sm font-mono">
                          {searchResult.contacts.phone && (
                            <div>Телефон: <span className="text-green-400">{searchResult.contacts.phone}</span></div>
                          )}
                          {searchResult.contacts.email && (
                            <div>Email: <span className="text-blue-400">{searchResult.contacts.email}</span></div>
                          )}
                          {searchResult.contacts.address && (
                            <div>Адрес: <span className="text-yellow-400">{searchResult.contacts.address}</span></div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Social Media Profiles */}
                {searchResult.socialProfiles && searchResult.socialProfiles.length > 0 && (
                  <div className="gradient-bg rounded-xl p-6 border border-border">
                    <h3 className="text-xl font-semibold mb-6">Профили в социальных сетях</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {searchResult.socialProfiles.map((profile, index) => (
                        <div key={index} className="code-block rounded-lg p-4">
                          <div className="flex items-center space-x-3 mb-3">
                            <i className={`fab fa-${profile.platform.toLowerCase()} text-xl`}></i>
                            <div>
                              <h4 className="font-medium">{profile.platform}</h4>
                              <p className="text-xs text-muted-foreground">{profile.url}</p>
                            </div>
                          </div>
                          <div className="text-sm space-y-1">
                            <div>Username: <span className="text-green-400">{profile.username}</span></div>
                            {profile.friends && (
                              <div>Друзей: <span className="text-yellow-400">{profile.friends}</span></div>
                            )}
                            {profile.lastActive && (
                              <div>Последняя активность: <span className="text-blue-400">{profile.lastActive}</span></div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Additional Information */}
                {searchResult.additionalInfo && (
                  <div className="gradient-bg rounded-xl p-6 border border-border">
                    <h3 className="text-xl font-semibold mb-6">Дополнительная информация</h3>
                    <div className="space-y-4">
                      {(searchResult.additionalInfo.work || searchResult.additionalInfo.education) && (
                        <div className="code-block rounded-lg p-4">
                          <h4 className="text-green-400 font-medium mb-2">🏢 Работа и образование</h4>
                          <div className="text-sm space-y-2">
                            {searchResult.additionalInfo.work && (
                              <div>Работа: <span className="text-white">{searchResult.additionalInfo.work}</span></div>
                            )}
                            {searchResult.additionalInfo.position && (
                              <div>Должность: <span className="text-blue-400">{searchResult.additionalInfo.position}</span></div>
                            )}
                            {searchResult.additionalInfo.education && (
                              <div>Образование: <span className="text-yellow-400">{searchResult.additionalInfo.education}</span></div>
                            )}
                          </div>
                        </div>
                      )}

                      {searchResult.additionalInfo.warnings && (
                        <div className="code-block rounded-lg p-4">
                          <h4 className="text-red-400 font-medium mb-2">⚠️ Предупреждения</h4>
                          <div className="text-sm space-y-2">
                            {searchResult.additionalInfo.warnings.map((warning, index) => (
                              <div key={index} className="text-red-400">⚠ {warning}</div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
