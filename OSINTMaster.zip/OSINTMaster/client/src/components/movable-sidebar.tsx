import { useState } from "react";
import { ThemeSwitcher } from "./theme-provider";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

type SidebarPosition = "left" | "right" | "top" | "bottom";

export function MovableSidebar({ activeSection, onSectionChange }: SidebarProps) {
  const [position, setPosition] = useState<SidebarPosition>("left");

  const togglePosition = () => {
    const positions: SidebarPosition[] = ["left", "right", "top", "bottom"];
    const currentIndex = positions.indexOf(position);
    const nextIndex = (currentIndex + 1) % positions.length;
    setPosition(positions[nextIndex]);
  };

  const getPositionClasses = () => {
    switch (position) {
      case "left":
        return "fixed left-0 top-0 w-80 h-screen flex-col";
      case "right":
        return "fixed right-0 top-0 w-80 h-screen flex-col";
      case "top":
        return "fixed top-0 left-0 w-full h-20 flex-row overflow-x-auto";
      case "bottom":
        return "fixed bottom-0 left-0 w-full h-20 flex-row overflow-x-auto";
    }
  };

  const getMainContentClasses = () => {
    switch (position) {
      case "left":
        return "ml-80";
      case "right":
        return "mr-80";
      case "top":
        return "mt-20";
      case "bottom":
        return "mb-20";
    }
  };

  const navigationItems = [
    {
      title: "ИИ Ассистенты",
      items: [
        { id: "ai-chat", icon: "fas fa-robot", label: "AI Чат (Grok + DeepSeek)" },
      ],
    },
    {
      title: "Валидация данных",
      items: [
        { id: "phone-validator", icon: "fas fa-phone", label: "Пробив номеров" },
        { id: "document-validator", icon: "fas fa-id-card", label: "Проверка документов" },
      ],
    },
    {
      title: "OSINT Инструменты",
      items: [
        { id: "person-search", icon: "fas fa-user-secret", label: "Поиск личности" },
        { id: "social-analyzer", icon: "fas fa-users", label: "Анализ соцсетей" },
        { id: "metadata-analyzer", icon: "fas fa-file-code", label: "Анализ метаданных" },
        { id: "geo-tracker", icon: "fas fa-map-marker-alt", label: "Геолокация" },
      ],
    },
    {
      title: "Softs",
      items: [
        { id: "softs-probiv", icon: "fas fa-cogs", label: "Пробив" },
        { id: "softs-snos", icon: "fas fa-upload", label: "Снос" },
      ],
    },
    {
      title: "Продвинутые",
      items: [
        { id: "telegram-bots", icon: "fab fa-telegram", label: "Telegram боты" },
        { id: "dorks-engine", icon: "fas fa-search-plus", label: "Google Дорки" },
        { id: "snoser", icon: "fas fa-eye", label: "Сносер" },
        { id: "bomber", icon: "fas fa-bomb", label: "SMS Бомбер" },
      ],
    },
  ];

  return (
    <>
      <aside
        data-testid="sidebar"
        className={cn(
          "bg-card border-border sidebar-transition z-20",
          position === "top" || position === "bottom" ? "border-b" : "border-r",
          getPositionClasses()
        )}
      >
        {/* Header */}
        <div className={cn("p-6 border-b border-border", position === "top" || position === "bottom" ? "min-w-max" : "")}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-search text-primary-foreground text-sm"></i>
              </div>
              <h1 className="text-xl font-semibold">OSINT Pro</h1>
            </div>
            <button
              data-testid="sidebar-move-btn"
              onClick={togglePosition}
              className="text-muted-foreground hover:text-foreground transition-colors"
              title="Переместить меню"
            >
              <i className="fas fa-arrows-alt"></i>
            </button>
          </div>
          
          {(position === "left" || position === "right") && <ThemeSwitcher />}
        </div>

        {/* Navigation */}
        <nav className={cn(
          "flex-1 p-4 space-y-2 overflow-y-auto",
          position === "top" || position === "bottom" ? "flex space-x-4 space-y-0" : ""
        )}>
          {navigationItems.map((section) => (
            <div key={section.title} className={cn("space-y-1", position === "top" || position === "bottom" ? "min-w-max" : "")}>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 py-2">
                {section.title}
              </h3>
              {section.items.map((item) => (
                <button
                  key={item.id}
                  data-testid={`nav-${item.id}`}
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    "nav-link flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors w-full text-left",
                    activeSection === item.id
                      ? "bg-accent text-accent-foreground"
                      : "hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <i className={`${item.icon} text-primary`}></i>
                  <span className={position === "top" || position === "bottom" ? "whitespace-nowrap" : ""}>
                    {item.label}
                  </span>
                </button>
              ))}
            </div>
          ))}
        </nav>
      </aside>

      {/* Spacer for main content */}
      <div className={cn("transition-all duration-300", getMainContentClasses())} />
    </>
  );
}
