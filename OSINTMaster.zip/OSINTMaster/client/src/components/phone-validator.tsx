import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

interface PhoneValidationResult {
  phoneNumber: string;
  isValid: boolean;
  country?: string;
  region?: string;
  operator?: string;
  phoneType?: string;
  socialProfiles?: {
    whatsapp?: boolean;
    telegram?: boolean;
    viber?: boolean;
  };
}

export function PhoneValidator() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [bulkNumbers, setBulkNumbers] = useState("");
  const [validationResult, setValidationResult] = useState<PhoneValidationResult | null>(null);
  const [sources, setSources] = useState({
    telegram: true,
    whatsapp: true,
    viber: false,
  });

  const validatePhoneMutation = useMutation({
    mutationFn: async (phone: string) => {
      const response = await apiRequest("POST", "/api/phone/validate", { 
        phoneNumber: phone,
        sources 
      });
      return response.json();
    },
    onSuccess: (data) => {
      setValidationResult(data);
    },
  });

  const handleValidate = () => {
    if (!phoneNumber.trim()) return;
    validatePhoneMutation.mutate(phoneNumber);
  };

  const handleBulkProcess = () => {
    const numbers = bulkNumbers.split('\n').filter(n => n.trim());
    // TODO: Implement bulk processing
    console.log('Bulk processing:', numbers);
  };

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Пробив номеров телефонов</h2>
          <p className="text-muted-foreground">
            Валидация номеров с определением региона, оператора и дополнительной информации
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Ввод номера</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Номер телефона</label>
                <input
                  data-testid="phone-input"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+7 999 123-45-67"
                  className="w-full px-4 py-3 terminal-input rounded-lg text-lg font-mono focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              
              <div className="flex space-x-3">
                <button
                  data-testid="validate-btn"
                  onClick={handleValidate}
                  disabled={!phoneNumber.trim() || validatePhoneMutation.isPending}
                  className="flex-1 px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors disabled:opacity-50"
                >
                  {validatePhoneMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Проверяем...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-search mr-2"></i>
                      Пробить номер
                    </>
                  )}
                </button>
                <button
                  data-testid="import-btn"
                  className="px-4 py-3 bg-secondary text-secondary-foreground rounded-lg font-medium hover:bg-secondary/80 transition-colors"
                >
                  <i className="fas fa-file-import"></i>
                </button>
              </div>

              <div className="border-t border-border pt-4">
                <h4 className="font-medium mb-3">Дополнительные источники</h4>
                <div className="space-y-2">
                  {Object.entries(sources).map(([key, value]) => (
                    <label key={key} className="flex items-center space-x-2">
                      <input
                        data-testid={`source-${key}`}
                        type="checkbox"
                        checked={value}
                        onChange={(e) => setSources(prev => ({ ...prev, [key]: e.target.checked }))}
                        className="rounded border-border"
                      />
                      <span className="text-sm capitalize">{key} проверка</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Results Panel */}
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Результаты анализа</h3>
            
            {!validationResult && !validatePhoneMutation.isPending && (
              <div className="text-center text-muted-foreground py-8">
                <i className="fas fa-phone-alt text-4xl mb-4 opacity-50"></i>
                <p>Введите номер телефона для анализа</p>
              </div>
            )}

            {validatePhoneMutation.isPending && (
              <div className="text-center py-8">
                <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
                <p className="text-muted-foreground">Анализируем номер...</p>
              </div>
            )}

            {validationResult && (
              <div className="space-y-4" data-testid="validation-results">
                {/* Basic Info */}
                <div className="code-block rounded-lg p-4">
                  <h4 className="text-green-400 font-medium mb-3">📱 Базовая информация</h4>
                  <div className="space-y-2 text-sm font-mono">
                    <div>Номер: <span className="text-white">{validationResult.phoneNumber}</span></div>
                    <div>Формат: <span className={validationResult.isValid ? "text-green-400" : "text-red-400"}>
                      {validationResult.isValid ? "✓ Валидный" : "✗ Невалидный"}
                    </span></div>
                    {validationResult.country && (
                      <div>Страна: <span className="text-blue-400">{validationResult.country}</span></div>
                    )}
                    {validationResult.region && (
                      <div>Регион: <span className="text-yellow-400">{validationResult.region}</span></div>
                    )}
                    {validationResult.operator && (
                      <div>Оператор: <span className="text-purple-400">{validationResult.operator}</span></div>
                    )}
                    {validationResult.phoneType && (
                      <div>Тип: <span className="text-cyan-400">{validationResult.phoneType}</span></div>
                    )}
                  </div>
                </div>

                {/* Social Media */}
                {validationResult.socialProfiles && (
                  <div className="code-block rounded-lg p-4">
                    <h4 className="text-blue-400 font-medium mb-3">🌐 Социальные сети</h4>
                    <div className="space-y-2 text-sm">
                      {Object.entries(validationResult.socialProfiles).map(([platform, found]) => (
                        <div key={platform} className="flex items-center justify-between">
                          <span className="capitalize">{platform}</span>
                          <span className={found ? "text-green-400" : "text-red-400"}>
                            {found ? "✓ Зарегистрирован" : "✗ Не найден"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Bulk Processing */}
        <div className="mt-8 gradient-bg rounded-xl p-6 border border-border">
          <h3 className="text-xl font-semibold mb-6">Массовая обработка</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Список номеров</label>
              <textarea
                data-testid="bulk-numbers"
                rows={6}
                value={bulkNumbers}
                onChange={(e) => setBulkNumbers(e.target.value)}
                placeholder="+7 999 123-45-67&#10;+7 999 123-45-68&#10;+7 999 123-45-69"
                className="w-full px-4 py-3 terminal-input rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Настройки обработки</label>
              <div className="space-y-3">
                <select
                  data-testid="processing-mode"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                >
                  <option>Быстрая проверка</option>
                  <option>Полный анализ</option>
                  <option>Только валидация</option>
                </select>
                <div className="flex space-x-3">
                  <button
                    data-testid="bulk-process-btn"
                    onClick={handleBulkProcess}
                    className="flex-1 px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors"
                  >
                    Запустить
                  </button>
                  <button
                    data-testid="bulk-download-btn"
                    className="px-4 py-3 bg-secondary text-secondary-foreground rounded-lg font-medium hover:bg-secondary/80 transition-colors"
                  >
                    <i className="fas fa-download"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
