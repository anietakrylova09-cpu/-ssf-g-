import { useState } from "react";

export function GeoTracker() {
  const [coordinates, setCoordinates] = useState("");
  const [address, setAddress] = useState("");

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Геолокация и карты</h2>
          <p className="text-muted-foreground">
            Анализ координат, адресов и поиск информации по местоположению
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Поиск по координатам</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Координаты (lat, lng)</label>
                <input
                  data-testid="coordinates-input"
                  type="text"
                  value={coordinates}
                  onChange={(e) => setCoordinates(e.target.value)}
                  placeholder="55.7558, 37.6176"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <button
                data-testid="search-coordinates-btn"
                className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors"
              >
                <i className="fas fa-map-marker-alt mr-2"></i>
                Найти по координатам
              </button>
            </div>
          </div>

          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Поиск по адресу</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Адрес</label>
                <input
                  data-testid="address-input"
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Москва, Красная площадь, 1"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <button
                data-testid="search-address-btn"
                className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors"
              >
                <i className="fas fa-search mr-2"></i>
                Найти координаты
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-muted-foreground">
          <i className="fas fa-map text-4xl mb-4 opacity-50"></i>
          <p>Введите координаты или адрес для анализа</p>
        </div>
      </div>
    </section>
  );
}
