module.exports = {
  appId: 'com.osint-platform.app',
  productName: 'OSINT Platform',
  directories: {
    output: 'dist-electron'
  },
  files: [
    'electron/**/*',
    'dist/**/*',
    'server/**/*',
    'shared/**/*',
    'node_modules/**/*',
    {
      from: '.',
      filter: ['package.json']
    }
  ],
  extraMetadata: {
    main: 'electron/main.js'
  },
  win: {
    target: [
      {
        target: 'nsis',
        arch: ['x64', 'ia32']
      },
      {
        target: 'portable',
        arch: ['x64', 'ia32']
      }
    ],
    icon: 'electron/assets/icon.ico',
    publisherName: 'OSINT Platform',
    verifyUpdateCodeSignature: false
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
    createDesktopShortcut: true,
    createStartMenuShortcut: true,
    shortcutName: 'OSINT Platform',
    uninstallDisplayName: 'OSINT Platform',
    deleteAppDataOnUninstall: true,
    installerIcon: 'electron/assets/icon.ico',
    uninstallerIcon: 'electron/assets/icon.ico',
    installerHeaderIcon: 'electron/assets/icon.ico',
    include: 'installer.nsh'
  },
  portable: {
    artifactName: 'OSINT-Platform-Portable-${version}.${ext}'
  },
  linux: {
    target: [
      {
        target: 'AppImage',
        arch: ['x64']
      },
      {
        target: 'deb',
        arch: ['x64']
      }
    ],
    category: 'Utility',
    icon: 'electron/assets/icon.png'
  },
  mac: {
    target: [
      {
        target: 'dmg',
        arch: ['x64', 'arm64']
      }
    ],
    icon: 'electron/assets/icon.icns',
    category: 'public.app-category.utilities'
  },
  dmg: {
    title: 'OSINT Platform',
    icon: 'electron/assets/icon.icns'
  },
  publish: null
};