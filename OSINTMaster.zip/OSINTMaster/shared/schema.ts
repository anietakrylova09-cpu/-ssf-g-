import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const osintSearches = pgTable("osint_searches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  searchType: text("search_type").notNull(), // 'phone', 'person', 'social', 'metadata'
  query: text("query").notNull(),
  results: jsonb("results"),
  status: text("status").notNull().default("pending"), // 'pending', 'completed', 'failed'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiConversations = pgTable("ai_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  messages: jsonb("messages").notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const phoneValidations = pgTable("phone_validations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: text("phone_number").notNull(),
  isValid: boolean("is_valid").notNull(),
  country: text("country"),
  region: text("region"),
  operator: text("operator"),
  phoneType: text("phone_type"),
  socialProfiles: jsonb("social_profiles"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertOsintSearchSchema = createInsertSchema(osintSearches).pick({
  searchType: true,
  query: true,
  results: true,
  status: true,
});

export const insertAiConversationSchema = createInsertSchema(aiConversations).pick({
  messages: true,
});

export const insertPhoneValidationSchema = createInsertSchema(phoneValidations).pick({
  phoneNumber: true,
  isValid: true,
  country: true,
  region: true,
  operator: true,
  phoneType: true,
  socialProfiles: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertOsintSearch = z.infer<typeof insertOsintSearchSchema>;
export type OsintSearch = typeof osintSearches.$inferSelect;
export type InsertAiConversation = z.infer<typeof insertAiConversationSchema>;
export type AiConversation = typeof aiConversations.$inferSelect;
export type InsertPhoneValidation = z.infer<typeof insertPhoneValidationSchema>;
export type PhoneValidation = typeof phoneValidations.$inferSelect;

// AI Chat validation schemas
export const aiChatRequestSchema = z.object({
  message: z.string().min(1, "Сообщение не может быть пустым").max(4000, "Сообщение слишком длинное"),
});

export const aiHealthStatusSchema = z.object({
  service: z.enum(["grok", "deepseek"]),
  status: z.enum(["online", "offline", "error"]),
  responseTime: z.number().optional(),
  error: z.string().optional(),
  lastChecked: z.string(),
});

export type AiChatRequest = z.infer<typeof aiChatRequestSchema>;
export type AiHealthStatus = z.infer<typeof aiHealthStatusSchema>;
