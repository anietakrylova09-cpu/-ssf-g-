import { motion } from "framer-motion";

export function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.6,
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const pulseVariants = {
    animate: {
      scale: [1, 1.05, 1],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  const glowVariants = {
    animate: {
      boxShadow: [
        "0 0 20px rgba(168, 85, 247, 0.4)",
        "0 0 40px rgba(168, 85, 247, 0.6)",
        "0 0 20px rgba(168, 85, 247, 0.4)"
      ],
      transition: {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <section className="min-h-screen p-6 bg-gradient-to-br from-purple-900/20 via-background to-pink-900/20">
      <motion.div 
        className="max-w-4xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header */}
        <motion.header 
          className="mb-12 text-center"
          variants={itemVariants}
        >
          <motion.div 
            className="inline-block"
            variants={pulseVariants}
            animate="animate"
          >
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-400 to-purple-600 bg-clip-text text-transparent">
              💜 Amalya
            </h1>
          </motion.div>
          <motion.p 
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
            variants={itemVariants}
          >
            Мощная OSINT платформа для глубокого анализа и пробива данных
          </motion.p>
        </motion.header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* About Section */}
          <motion.div 
            className="gradient-bg rounded-xl p-8 border border-border relative overflow-hidden"
            variants={itemVariants}
            whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
          >
            <motion.div
              className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-pink-500"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
            />
            
            <h2 className="text-2xl font-bold mb-6 text-purple-400">
              🔍 О платформе
            </h2>
            
            <div className="space-y-4 text-muted-foreground">
              <motion.p variants={itemVariants}>
                <strong className="text-foreground">Amalya</strong> — это комплексная OSINT платформа, 
                созданная с любовью для сообщества исследователей и аналитиков.
              </motion.p>
              
              <motion.p variants={itemVariants}>
                Платформа объединяет мощные инструменты анализа с современными 
                ИИ-технологиями для получения максимально точных результатов.
              </motion.p>
              
              <motion.div 
                className="bg-purple-900/20 rounded-lg p-4 border border-purple-500/20"
                variants={itemVariants}
              >
                <h3 className="font-semibold text-purple-300 mb-2">🤖 Двойная ИИ система:</h3>
                <ul className="space-y-1 text-sm">
                  <li>• <span className="text-blue-400">Grok</span> — для быстрого анализа</li>
                  <li>• <span className="text-green-400">DeepSeek</span> — для глубокого изучения</li>
                </ul>
              </motion.div>
            </div>
          </motion.div>

          {/* Authors Section */}
          <motion.div 
            className="gradient-bg rounded-xl p-8 border border-border relative overflow-hidden"
            variants={glowVariants}
            animate="animate"
          >
            <motion.div
              className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 to-purple-500"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1, delay: 0.7 }}
            />
            
            <h2 className="text-2xl font-bold mb-6 text-pink-400">
              👥 Создатели
            </h2>
            
            <div className="space-y-6">
              <motion.div 
                className="flex items-center space-x-4 p-4 bg-purple-900/30 rounded-lg border border-purple-500/30"
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.05, 
                  backgroundColor: "rgba(147, 51, 234, 0.2)",
                  transition: { duration: 0.2 }
                }}
              >
                <div className="text-3xl">🌟</div>
                <div>
                  <h3 className="font-bold text-purple-300">Amalya</h3>
                  <p className="text-sm text-muted-foreground">@cluim</p>
                  <p className="text-xs text-purple-400">Основатель и главный разработчик</p>
                </div>
              </motion.div>
              
              <motion.div 
                className="flex items-center space-x-4 p-4 bg-pink-900/30 rounded-lg border border-pink-500/30"
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.05, 
                  backgroundColor: "rgba(236, 72, 153, 0.2)",
                  transition: { duration: 0.2 }
                }}
              >
                <div className="text-3xl">🤫</div>
                <div>
                  <h3 className="font-bold text-pink-300">шепот</h3>
                  <p className="text-sm text-muted-foreground">@oxaul</p>
                  <p className="text-xs text-pink-400">Со-создатель и архитектор</p>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Adapters Section */}
        <motion.div 
          className="gradient-bg rounded-xl p-8 border border-border mb-8"
          variants={itemVariants}
        >
          <h2 className="text-2xl font-bold mb-6 text-center text-blue-400">
            📱 Официальные адаптеры
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.a
              href="https://t.me/adapetamaly"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-4 p-6 bg-blue-900/30 rounded-lg border border-blue-500/30 hover:bg-blue-900/50 transition-all group"
              whileHover={{ 
                scale: 1.03,
                boxShadow: "0 10px 30px rgba(59, 130, 246, 0.3)"
              }}
              whileTap={{ scale: 0.98 }}
            >
              <motion.div 
                className="text-4xl"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0 }}
              >
                💜
              </motion.div>
              <div>
                <h3 className="font-bold text-blue-300 group-hover:text-blue-200">
                  адаптер Амалии
                </h3>
                <p className="text-sm text-blue-400">t.me/adapetamaly</p>
                <p className="text-xs text-muted-foreground">Официальная поддержка и обновления</p>
              </div>
              <motion.div
                className="ml-auto text-blue-400"
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                →
              </motion.div>
            </motion.a>
            
            <motion.a
              href="https://t.me/adp_oxaul"
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-4 p-6 bg-pink-900/30 rounded-lg border border-pink-500/30 hover:bg-pink-900/50 transition-all group"
              whileHover={{ 
                scale: 1.03,
                boxShadow: "0 10px 30px rgba(236, 72, 153, 0.3)"
              }}
              whileTap={{ scale: 0.98 }}
            >
              <motion.div 
                className="text-4xl"
                animate={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 1 }}
              >
                🤫
              </motion.div>
              <div>
                <h3 className="font-bold text-pink-300 group-hover:text-pink-200">
                  адаптер шепота
                </h3>
                <p className="text-sm text-pink-400">t.me/adp_oxaul</p>
                <p className="text-xs text-muted-foreground">Техническая поддержка и решения</p>
              </div>
              <motion.div
                className="ml-auto text-pink-400"
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
              >
                →
              </motion.div>
            </motion.a>
          </div>
        </motion.div>

        {/* Features Section */}
        <motion.div 
          className="gradient-bg rounded-xl p-8 border border-border"
          variants={itemVariants}
        >
          <h2 className="text-2xl font-bold mb-6 text-center text-green-400">
            ⚡ Возможности платформы
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: "📞", title: "Анализ телефонов", desc: "Проверка номеров, операторов, соцсетей" },
              { icon: "🌍", title: "IP геолокация", desc: "Определение местоположения и провайдера" },
              { icon: "🔍", title: "Поиск людей", desc: "Поиск информации по ФИО и данным" },
              { icon: "📸", title: "Анализ медиа", desc: "Извлечение метаданных из файлов" },
              { icon: "🤖", title: "ИИ ассистент", desc: "Помощь в аналитике и исследованиях" },
              { icon: "🛠️", title: "Внешние инструменты", desc: "Интеграция дополнительного ПО" }
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="text-center p-4 bg-gray-900/30 rounded-lg border border-gray-700/30"
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.05,
                  backgroundColor: "rgba(34, 197, 94, 0.1)",
                  borderColor: "rgba(34, 197, 94, 0.3)"
                }}
                transition={{ duration: 0.2 }}
              >
                <motion.div 
                  className="text-3xl mb-2"
                  animate={{ 
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 3, 
                    repeat: Infinity, 
                    delay: index * 0.2 
                  }}
                >
                  {feature.icon}
                </motion.div>
                <h3 className="font-semibold text-green-300 mb-1">{feature.title}</h3>
                <p className="text-xs text-muted-foreground">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Footer */}
        <motion.footer 
          className="mt-12 text-center"
          variants={itemVariants}
        >
          <motion.p 
            className="text-muted-foreground"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            Создано с 💜 для сообщества OSINT исследователей
          </motion.p>
          <motion.p 
            className="text-sm text-purple-400 mt-2"
            variants={itemVariants}
          >
            Версия 1.0.0 | Все права защищены © 2025 Amalya Team
          </motion.p>
        </motion.footer>
      </motion.div>
    </section>
  );
}