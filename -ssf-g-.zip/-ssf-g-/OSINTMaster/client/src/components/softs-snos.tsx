import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface UploadedSoftware {
  id: string;
  name: string;
  type: "executable" | "script" | "api";
  description: string;
  uploadedAt: string;
  status: "active" | "inactive" | "error";
  apiEndpoint?: string;
  parameters?: string[];
}

export function SoftsSnos() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedSofts, setUploadedSofts] = useState<UploadedSoftware[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [softwareConfig, setSoftwareConfig] = useState({
    name: "",
    type: "executable" as "executable" | "script" | "api",
    description: "",
    apiEndpoint: "",
    parameters: [] as string[],
  });

  const uploadSoftwareMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest("POST", "/api/softs/upload", formData);
      return response.json();
    },
    onSuccess: (data) => {
      setUploadedSofts(prev => [data, ...prev]);
      setSelectedFile(null);
      setSoftwareConfig({
        name: "",
        type: "executable",
        description: "",
        apiEndpoint: "",
        parameters: [],
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      // Auto-detect software type
      if (file.name.endsWith('.exe')) {
        setSoftwareConfig(prev => ({ ...prev, type: "executable" }));
      } else if (file.name.endsWith('.py') || file.name.endsWith('.js')) {
        setSoftwareConfig(prev => ({ ...prev, type: "script" }));
      }
    }
  };

  const handleUpload = () => {
    if (!selectedFile || !softwareConfig.name.trim()) return;

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('config', JSON.stringify(softwareConfig));
    
    uploadSoftwareMutation.mutate(formData);
  };

  const removeSoftware = (id: string) => {
    setUploadedSofts(prev => prev.filter(soft => soft.id !== id));
  };

  const toggleSoftwareStatus = (id: string) => {
    setUploadedSofts(prev => prev.map(soft => 
      soft.id === id 
        ? { ...soft, status: soft.status === "active" ? "inactive" : "active" }
        : soft
    ));
  };

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Softs - Снос</h2>
          <p className="text-muted-foreground">
            Загрузка и управление внешними программами для интеграции с AI анализом
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="space-y-6">
            <div className="gradient-bg rounded-xl p-6 border border-border">
              <h3 className="text-xl font-semibold mb-6">Загрузка программ</h3>
              
              <div className="space-y-4">
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileSelect}
                    accept=".exe,.py,.js,.jar,.sh,.bat"
                    className="hidden"
                    data-testid="file-input"
                  />
                  
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="cursor-pointer border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors"
                  >
                    <i className="fas fa-cloud-upload-alt text-4xl text-muted-foreground mb-4"></i>
                    <p className="text-lg font-medium mb-2">Выберите программу для загрузки</p>
                    <p className="text-sm text-muted-foreground">
                      Поддерживаются: .exe, .py, .js, .jar, .sh, .bat
                    </p>
                    {selectedFile && (
                      <div className="mt-4 p-3 bg-accent rounded-lg">
                        <p className="font-medium">Выбранный файл:</p>
                        <p className="text-sm text-muted-foreground">{selectedFile.name}</p>
                        <p className="text-xs text-muted-foreground">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                      </div>
                    )}
                  </div>
                </div>

                {selectedFile && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Название программы</label>
                      <input
                        data-testid="software-name"
                        type="text"
                        value={softwareConfig.name}
                        onChange={(e) => setSoftwareConfig(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Введите название программы"
                        className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Тип программы</label>
                      <select
                        data-testid="software-type"
                        value={softwareConfig.type}
                        onChange={(e) => setSoftwareConfig(prev => ({ ...prev, type: e.target.value as any }))}
                        className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                      >
                        <option value="executable">Исполняемый файл (.exe)</option>
                        <option value="script">Скрипт (.py, .js)</option>
                        <option value="api">API endpoint</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Описание</label>
                      <textarea
                        data-testid="software-description"
                        rows={3}
                        value={softwareConfig.description}
                        onChange={(e) => setSoftwareConfig(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Описание функций программы"
                        className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>

                    {softwareConfig.type === "api" && (
                      <div>
                        <label className="block text-sm font-medium mb-2">API Endpoint</label>
                        <input
                          data-testid="api-endpoint"
                          type="url"
                          value={softwareConfig.apiEndpoint}
                          onChange={(e) => setSoftwareConfig(prev => ({ ...prev, apiEndpoint: e.target.value }))}
                          placeholder="https://api.example.com/endpoint"
                          className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                        />
                      </div>
                    )}

                    <button
                      data-testid="upload-btn"
                      onClick={handleUpload}
                      disabled={!softwareConfig.name.trim() || uploadSoftwareMutation.isPending}
                      className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {uploadSoftwareMutation.isPending ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                          Загружается...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-upload mr-2"></i>
                          Загрузить программу
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* AI Integration */}
            <div className="gradient-bg rounded-xl p-6 border border-border">
              <h3 className="text-xl font-semibold mb-4">AI интеграция</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-robot text-primary"></i>
                  <span>ИИ автоматически анализирует результаты ваших программ</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-code text-blue-400"></i>
                  <span>Генерирует код для интеграции и улучшений</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-chart-line text-green-400"></i>
                  <span>Создает сводные отчеты и визуализации</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-search-plus text-yellow-400"></i>
                  <span>Предлагает дополнительные источники данных</span>
                </div>
              </div>
            </div>
          </div>

          {/* Uploaded Software Management */}
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Управление программами</h3>
            
            <div className="space-y-4 max-h-96 overflow-y-auto" data-testid="software-list">
              {uploadedSofts.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  <i className="fas fa-folder-open text-4xl mb-4 opacity-50"></i>
                  <p>Загруженные программы появятся здесь</p>
                </div>
              )}

              {uploadedSofts.map((software) => (
                <div key={software.id} className="code-block rounded-lg p-4" data-testid={`software-${software.id}`}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-white font-medium">{software.name}</h4>
                        <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium ${
                          software.status === "active" 
                            ? "bg-green-100 text-green-800"
                            : software.status === "error"
                            ? "bg-red-100 text-red-800"
                            : "bg-gray-100 text-gray-800"
                        }`}>
                          {software.status === "active" ? "Активна" : software.status === "error" ? "Ошибка" : "Неактивна"}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{software.description}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                        <span>Тип: {software.type}</span>
                        <span>Загружена: {software.uploadedAt}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        data-testid={`toggle-${software.id}`}
                        onClick={() => toggleSoftwareStatus(software.id)}
                        className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                          software.status === "active"
                            ? "bg-yellow-600 hover:bg-yellow-700 text-white"
                            : "bg-green-600 hover:bg-green-700 text-white"
                        }`}
                      >
                        {software.status === "active" ? "Отключить" : "Включить"}
                      </button>
                      <button
                        data-testid={`remove-${software.id}`}
                        onClick={() => removeSoftware(software.id)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-medium transition-colors"
                      >
                        Удалить
                      </button>
                    </div>
                  </div>
                  
                  {software.apiEndpoint && (
                    <div className="text-xs text-blue-400 bg-black/30 p-2 rounded mt-2">
                      Endpoint: {software.apiEndpoint}
                    </div>
                  )}

                  {software.parameters && software.parameters.length > 0 && (
                    <div className="text-xs text-muted-foreground mt-2">
                      Параметры: {software.parameters.join(", ")}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 gradient-bg rounded-xl p-6 border border-border">
          <h3 className="text-xl font-semibold mb-4">Инструкции по использованию</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-primary mb-3">Для исполняемых файлов (.exe):</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Убедитесь что программа работает через командную строку</li>
                <li>• Программа должна принимать параметры и выводить результат</li>
                <li>• Желательно JSON формат вывода для лучшего анализа</li>
                <li>• ИИ будет запускать программу и анализировать результаты</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-blue-400 mb-3">Для API endpoints:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Укажите полный URL endpoint</li>
                <li>• API должен поддерживать POST запросы</li>
                <li>• Ответ должен быть в JSON формате</li>
                <li>• ИИ будет отправлять запросы и анализировать ответы</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}