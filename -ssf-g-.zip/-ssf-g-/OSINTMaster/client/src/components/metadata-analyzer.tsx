import { useState } from "react";

export function MetadataAnalyzer() {
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Анализ метаданных</h2>
          <p className="text-muted-foreground">
            Извлечение и анализ метаданных из файлов изображений и документов
          </p>
        </header>

        <div className="gradient-bg rounded-xl p-6 border border-border">
          <div className="text-center">
            <input
              data-testid="file-input"
              type="file"
              onChange={handleFileChange}
              accept="image/*,.pdf,.doc,.docx"
              className="hidden"
              id="file-upload"
            />
            <label
              htmlFor="file-upload"
              className="cursor-pointer block p-8 border-2 border-dashed border-border rounded-lg hover:border-primary transition-colors"
            >
              <i className="fas fa-upload text-4xl text-muted-foreground mb-4"></i>
              <p className="text-lg font-medium">Загрузите файл для анализа</p>
              <p className="text-sm text-muted-foreground mt-2">
                Поддерживаются: JPG, PNG, PDF, DOC, DOCX
              </p>
            </label>

            {file && (
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <p className="font-medium">Выбранный файл:</p>
                <p className="text-sm text-muted-foreground">{file.name}</p>
                <button
                  data-testid="analyze-metadata-btn"
                  className="mt-3 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/80 transition-colors"
                >
                  <i className="fas fa-search mr-2"></i>
                  Анализировать метаданные
                </button>
              </div>
            )}
          </div>
        </div>

        {!file && (
          <div className="mt-8 text-center text-muted-foreground">
            <i className="fas fa-file-code text-4xl mb-4 opacity-50"></i>
            <p>Загрузите файл для анализа метаданных</p>
          </div>
        )}
      </div>
    </section>
  );
}
