import { useTheme } from "@/hooks/use-theme";

const themes = [
  { name: "pink", color: "bg-pink-500" },
  { name: "blue", color: "bg-blue-500" },
  { name: "green", color: "bg-green-500" },
  { name: "purple", color: "bg-purple-500" },
] as const;

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="mt-4">
      <label className="text-sm font-medium text-muted-foreground block mb-2">
        Тема интерфейса
      </label>
      <div className="flex space-x-2">
        {themes.map((t) => (
          <button
            key={t.name}
            data-testid={`theme-${t.name}`}
            onClick={() => setTheme(t.name)}
            className={`w-8 h-8 rounded-full ${t.color} border-2 transition-colors ${
              theme === t.name ? "border-foreground" : "border-transparent hover:border-foreground"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
