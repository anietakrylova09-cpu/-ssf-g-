import { useState } from "react";
import { useMutation } from "@tanstack/react-query";

export function GeoTracker() {
  const [coordinates, setCoordinates] = useState("");
  const [address, setAddress] = useState("");
  const [ipAddress, setIpAddress] = useState("");
  const [results, setResults] = useState<any>(null);
  
  const geolocateMutation = useMutation({
    mutationFn: async (data: { coordinates?: string; address?: string; ipAddress?: string }) => {
      const response = await fetch('/api/geo/locate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Ошибка при запросе геолокации');
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
    }
  });

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">🌍 Геолокация и IP анализ</h2>
          <p className="text-muted-foreground">
            Анализ координат, адресов и поиск информации по IP адресам. Определение местоположения, провайдера и уровня безопасности.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Поиск по координатам</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Координаты (lat, lng)</label>
                <input
                  data-testid="coordinates-input"
                  type="text"
                  value={coordinates}
                  onChange={(e) => setCoordinates(e.target.value)}
                  placeholder="55.7558, 37.6176"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <button
                data-testid="search-coordinates-btn"
                onClick={() => geolocateMutation.mutate({ coordinates })}
                disabled={!coordinates.trim() || geolocateMutation.isPending}
                className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors disabled:opacity-50"
              >
                <i className="fas fa-map-marker-alt mr-2"></i>
                {geolocateMutation.isPending ? 'Поиск...' : 'Найти по координатам'}
              </button>
            </div>
          </div>

          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Поиск по адресу</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Адрес</label>
                <input
                  data-testid="address-input"
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Москва, Красная площадь, 1"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <button
                data-testid="search-address-btn"
                onClick={() => geolocateMutation.mutate({ address })}
                disabled={!address.trim() || geolocateMutation.isPending}
                className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors disabled:opacity-50"
              >
                <i className="fas fa-search mr-2"></i>
                {geolocateMutation.isPending ? 'Поиск...' : 'Найти координаты'}
              </button>
            </div>
          </div>

          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6 text-blue-400">Анализ IP адреса</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">IP адрес</label>
                <input
                  data-testid="ip-input"
                  type="text"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  placeholder="192.168.1.1 или 8.8.8.8"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <button
                data-testid="search-ip-btn"
                onClick={() => geolocateMutation.mutate({ ipAddress })}
                disabled={!ipAddress.trim() || geolocateMutation.isPending}
                className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <i className="fas fa-globe mr-2"></i>
                {geolocateMutation.isPending ? 'Анализ...' : 'Анализировать IP'}
              </button>
            </div>
          </div>
        </div>

        {/* Results Display */}
        {results && (
          <div className="mt-8 gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-4">Результаты анализа</h3>
            
            {results.error ? (
              <div className="text-red-400 p-4 bg-red-900/20 rounded-lg">
                <i className="fas fa-exclamation-triangle mr-2"></i>
                {results.error}
              </div>
            ) : (
              <div className="space-y-4">
                {/* IP Analysis Results */}
                {results.ip && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-800">
                      <h4 className="font-semibold text-blue-400 mb-2">📍 Местоположение</h4>
                      <p><strong>IP:</strong> {results.ip}</p>
                      <p><strong>Страна:</strong> {results.location?.country}</p>
                      <p><strong>Регион:</strong> {results.location?.region}</p>
                      <p><strong>Город:</strong> {results.location?.city}</p>
                      <p><strong>Координаты:</strong> {results.location?.coordinates?.lat}, {results.location?.coordinates?.lng}</p>
                      <p><strong>Часовой пояс:</strong> {results.location?.timezone}</p>
                    </div>
                    
                    <div className="bg-green-900/20 p-4 rounded-lg border border-green-800">
                      <h4 className="font-semibold text-green-400 mb-2">🌐 Сеть</h4>
                      <p><strong>Провайдер:</strong> {results.network?.isp}</p>
                      <p><strong>Организация:</strong> {results.network?.organization}</p>
                      <p><strong>ASN:</strong> {results.network?.asn}</p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {results.network?.mobile && <span className="bg-blue-600 text-xs px-2 py-1 rounded">Мобильная сеть</span>}
                        {results.network?.proxy && <span className="bg-orange-600 text-xs px-2 py-1 rounded">Прокси</span>}
                        {results.network?.hosting && <span className="bg-purple-600 text-xs px-2 py-1 rounded">Хостинг</span>}
                      </div>
                    </div>
                    
                    <div className="bg-yellow-900/20 p-4 rounded-lg border border-yellow-800">
                      <h4 className="font-semibold text-yellow-400 mb-2">🔒 Безопасность</h4>
                      <p><strong>Риск-скор:</strong> 
                        <span className={`ml-2 px-2 py-1 rounded text-xs ${
                          results.security?.riskScore > 50 ? 'bg-red-600' : 
                          results.security?.riskScore > 20 ? 'bg-yellow-600' : 'bg-green-600'
                        }`}>
                          {results.security?.riskScore}/100
                        </span>
                      </p>
                      <div className="mt-2 space-y-1">
                        {results.security?.isProxy && <div className="text-orange-400">⚠️ Прокси-сервер</div>}
                        {results.security?.isHosting && <div className="text-purple-400">🏢 Хостинг провайдер</div>}
                        {results.security?.isMobile && <div className="text-blue-400">📱 Мобильная сеть</div>}
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Address/Coordinates Results */}
                {(results.coordinates || results.address) && (
                  <div className="bg-gray-900/20 p-4 rounded-lg border border-gray-800">
                    <h4 className="font-semibold mb-2">📍 Геолокация</h4>
                    {results.coordinates && (
                      <p><strong>Координаты:</strong> {results.coordinates.lat}, {results.coordinates.lng}</p>
                    )}
                    {results.address && (
                      <p><strong>Адрес:</strong> {results.address}</p>
                    )}
                    {results.details && (
                      <div className="mt-2 text-sm text-muted-foreground">
                        <p><strong>Страна:</strong> {results.details.country}</p>
                        <p><strong>Город:</strong> {results.details.city}</p>
                        {results.details.road && <p><strong>Улица:</strong> {results.details.road}</p>}
                        {results.details.postcode && <p><strong>Индекс:</strong> {results.details.postcode}</p>}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
        
        {!results && (
          <div className="mt-8 text-center text-muted-foreground">
            <i className="fas fa-map text-4xl mb-4 opacity-50"></i>
            <p>Введите координаты, адрес или IP адрес для анализа</p>
          </div>
        )}
      </div>
    </section>
  );
}
