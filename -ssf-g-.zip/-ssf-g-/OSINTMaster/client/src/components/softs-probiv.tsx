import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface SoftsResult {
  software: string;
  query: string;
  result: string;
  sources: string[];
  timestamp: string;
}

export function SoftsProbiv() {
  const [selectedSoft, setSelectedSoft] = useState("");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SoftsResult[]>([]);
  
  const executeQueryMutation = useMutation({
    mutationFn: async ({ software, query }: { software: string; query: string }) => {
      const response = await apiRequest("POST", "/api/softs/execute", { 
        software, 
        query,
        type: "probiv"
      });
      return response.json();
    },
    onSuccess: (data) => {
      setResults(prev => [data, ...prev]);
    },
  });

  const handleExecute = () => {
    if (!selectedSoft || !query.trim()) return;
    executeQueryMutation.mutate({ software: selectedSoft, query });
  };

  const availableSofts = [
    { id: "tg-bot-search", name: "Telegram Bot Search", description: "Поиск через Telegram ботов" },
    { id: "phone-checker", name: "Phone Checker", description: "Углубленная проверка номеров" },
    { id: "social-hunter", name: "Social Hunter", description: "Поиск в социальных сетях" },
    { id: "doc-validator", name: "Document Validator", description: "Проверка документов" },
    { id: "email-tracker", name: "Email Tracker", description: "Отслеживание email" },
  ];

  return (
    <section className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Softs - Пробив</h2>
          <p className="text-muted-foreground">
            Интеграция с внешними программами и API для глубокого анализа данных
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Software Selection */}
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Доступные программы</h3>
            
            <div className="space-y-3">
              {availableSofts.map((soft) => (
                <button
                  key={soft.id}
                  data-testid={`soft-${soft.id}`}
                  onClick={() => setSelectedSoft(soft.id)}
                  className={`w-full p-4 rounded-lg border transition-colors text-left ${
                    selectedSoft === soft.id
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border hover:border-primary/50 hover:bg-accent"
                  }`}
                >
                  <div className="font-medium">{soft.name}</div>
                  <div className="text-sm text-muted-foreground mt-1">{soft.description}</div>
                </button>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-border">
              <div className="text-sm text-muted-foreground">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>Статус: {availableSofts.length} программ доступно</span>
                </div>
                <div className="text-xs">
                  Загружайте свои программы в раздел "Снос" для интеграции с ИИ
                </div>
              </div>
            </div>
          </div>

          {/* Query Input */}
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Параметры запроса</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Выбранная программа</label>
                <input
                  data-testid="selected-software"
                  type="text"
                  value={selectedSoft ? availableSofts.find(s => s.id === selectedSoft)?.name || "" : ""}
                  disabled
                  placeholder="Выберите программу слева"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none opacity-50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Запрос/Данные</label>
                <textarea
                  data-testid="query-input"
                  rows={4}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Введите данные для анализа (номер телефона, ФИО, email и т.д.)"
                  className="w-full px-4 py-3 terminal-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <button
                data-testid="execute-btn"
                onClick={handleExecute}
                disabled={!selectedSoft || !query.trim() || executeQueryMutation.isPending}
                className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {executeQueryMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Выполняется...
                  </>
                ) : (
                  <>
                    <i className="fas fa-play mr-2"></i>
                    Запустить анализ
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Results */}
          <div className="gradient-bg rounded-xl p-6 border border-border">
            <h3 className="text-xl font-semibold mb-6">Результаты</h3>
            
            <div className="space-y-4 max-h-96 overflow-y-auto" data-testid="results-container">
              {results.length === 0 && !executeQueryMutation.isPending && (
                <div className="text-center text-muted-foreground py-8">
                  <i className="fas fa-cogs text-4xl mb-4 opacity-50"></i>
                  <p>Результаты анализа появятся здесь</p>
                </div>
              )}

              {executeQueryMutation.isPending && (
                <div className="text-center py-8">
                  <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
                  <p className="text-muted-foreground">Анализируем данные...</p>
                </div>
              )}

              {results.map((result, index) => (
                <div key={index} className="code-block rounded-lg p-4" data-testid={`result-${index}`}>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="text-green-400 font-medium">{result.software}</h4>
                      <p className="text-xs text-muted-foreground">{result.timestamp}</p>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-green-100 text-green-800">
                      Завершено
                    </span>
                  </div>
                  
                  <div className="space-y-2 text-sm font-mono">
                    <div>Запрос: <span className="text-white">{result.query}</span></div>
                    <div className="border-t border-border pt-2">
                      <div className="text-blue-400 mb-1">Результат:</div>
                      <div className="whitespace-pre-wrap text-white bg-black/30 p-3 rounded">
                        {result.result}
                      </div>
                    </div>
                    {result.sources.length > 0 && (
                      <div className="text-xs text-muted-foreground">
                        Источники: {result.sources.join(", ")}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Integration Info */}
        <div className="mt-8 gradient-bg rounded-xl p-6 border border-border">
          <h3 className="text-xl font-semibold mb-4">Интеграция с ИИ</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium text-primary">Grok (xAI) анализирует:</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Результаты программ для поиска закономерностей</li>
                <li>• Связи между найденными данными</li>
                <li>• Рекомендации по дополнительным проверкам</li>
                <li>• Формирование сводных отчетов</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-medium text-blue-400">DeepSeek дополняет:</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Глубокий анализ полученных данных</li>
                <li>• Создание профилей и досье</li>
                <li>• Поиск дополнительных источников</li>
                <li>• Генерация кода для новых проверок</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}