import { useState } from "react";
import { MovableSidebar } from "@/components/movable-sidebar";
import { AiChat } from "@/components/ai-chat";
import { PhoneValidator } from "@/components/phone-validator";
import { PersonSearch } from "@/components/person-search";
import { SocialAnalyzer } from "@/components/social-analyzer";
import { MetadataAnalyzer } from "@/components/metadata-analyzer";
import { GeoTracker } from "@/components/geo-tracker";
import { SoftsProbiv } from "@/components/softs-probiv";
import { SoftsSnos } from "@/components/softs-snos";
import { About } from "@/components/about";

export default function Home() {
  const [activeSection, setActiveSection] = useState("ai-chat");

  const renderActiveSection = () => {
    switch (activeSection) {
      case "ai-chat":
        return <AiChat />;
      case "phone-validator":
        return <PhoneValidator />;
      case "person-search":
        return <PersonSearch />;
      case "social-analyzer":
        return <SocialAnalyzer />;
      case "metadata-analyzer":
        return <MetadataAnalyzer />;
      case "geo-tracker":
        return <GeoTracker />;
      case "softs-probiv":
        return <SoftsProbiv />;
      case "softs-snos":
        return <SoftsSnos />;
      case "about":
        return <About />;
      default:
        return (
          <section className="min-h-screen p-6 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <i className="fas fa-cog text-6xl mb-4 opacity-50"></i>
              <p className="text-xl">Раздел в разработке</p>
              <p className="text-sm mt-2">Выберите другой инструмент из меню</p>
            </div>
          </section>
        );
    }
  };

  return (
    <div className="min-h-screen flex relative">
      <MovableSidebar
        activeSection={activeSection}
        onSectionChange={setActiveSection}
      />
      <main className="flex-1 transition-all duration-300">
        {renderActiveSection()}
      </main>
    </div>
  );
}
