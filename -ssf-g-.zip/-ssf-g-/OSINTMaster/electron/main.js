const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const isDev = process.env.NODE_ENV === 'development';

let mainWindow;
let serverProcess;

// Создание главного окна
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      webSecurity: !isDev
    },
    // icon: path.join(__dirname, 'assets', 'icon.png'), // Иконка будет добавлена позже
    show: false,
    titleBarStyle: 'default'
  });

  // Загрузка приложения
  const startUrl = isDev ? 'http://localhost:5000' : `file://${path.join(__dirname, '../dist/index.html')}`;
  mainWindow.loadURL(startUrl);

  // Показать окно когда готово
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    
    if (isDev) {
      mainWindow.webContents.openDevTools();
    }
  });

  // Обработка закрытия окна
  mainWindow.on('closed', () => {
    mainWindow = null;
    if (serverProcess) {
      serverProcess.kill();
    }
  });

  // Открывать внешние ссылки в браузере
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// Запуск сервера в продакшене
function startServer() {
  if (!isDev) {
    const serverPath = path.join(__dirname, '../server/index.js');
    serverProcess = spawn('node', [serverPath], {
      stdio: 'ignore',
      env: { ...process.env, NODE_ENV: 'production', PORT: '5000' }
    });
  }
}

// Создание меню приложения
function createMenu() {
  const template = [
    {
      label: 'Amalya',
      submenu: [
        {
          label: 'О программе',
          click: () => {
            const aboutWindow = new BrowserWindow({
              width: 400,
              height: 300,
              parent: mainWindow,
              modal: true,
              resizable: false,
              webPreferences: {
                nodeIntegration: false,
                contextIsolation: true
              }
            });
            
            aboutWindow.loadURL(`data:text/html;charset=utf-8,
              <html>
                <head>
                  <title>О программе</title>
                  <style>
                    body {
                      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                      text-align: center;
                      padding: 40px 20px;
                      margin: 0;
                      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                      color: white;
                    }
                    h1 { margin-bottom: 20px; font-size: 24px; }
                    p { margin: 10px 0; line-height: 1.5; }
                    .version { font-size: 14px; opacity: 0.8; margin-top: 20px; }
                  </style>
                </head>
                <body>
                  <h1>💜 Amalya</h1>
                  <p>Мощная OSINT платформа для пробива</p>
                  <p>Двойная ИИ система: Grok + DeepSeek</p>
                  <p>Создано с любовью для сообщества</p>
                  <div style="margin-top: 20px; font-size: 14px; opacity: 0.9;">
                    <p><strong>Авторы:</strong></p>
                    <p>🌟 Amalya @cluim</p>
                    <p>🤫 шепот @oxaul</p>
                    <p>📱 адаптер Амалии: <a href="https://t.me/adapetamaly" style="color: #64b5f6;">t.me/adapetamaly</a></p>
                    <p>📱 адаптер шепота: <a href="https://t.me/adp_oxaul" style="color: #64b5f6;">t.me/adp_oxaul</a></p>
                  </div>
                  <div class="version">Версия 1.0.0</div>
                </body>
              </html>
            `);
            
            aboutWindow.setMenu(null);
          }
        },
        { type: 'separator' },
        {
          label: 'Выход',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'Вид',
      submenu: [
        { 
          label: 'Перезагрузить',
          accelerator: 'CmdOrCtrl+R',
          click: () => mainWindow.reload()
        },
        { 
          label: 'Полноэкранный режим',
          accelerator: process.platform === 'darwin' ? 'Ctrl+Cmd+F' : 'F11',
          click: () => mainWindow.setFullScreen(!mainWindow.isFullScreen())
        },
        { type: 'separator' },
        {
          label: 'Уменьшить',
          accelerator: 'CmdOrCtrl+-',
          click: () => {
            const currentZoom = mainWindow.webContents.getZoomFactor();
            mainWindow.webContents.setZoomFactor(Math.max(currentZoom - 0.1, 0.5));
          }
        },
        {
          label: 'Увеличить',
          accelerator: 'CmdOrCtrl+=',
          click: () => {
            const currentZoom = mainWindow.webContents.getZoomFactor();
            mainWindow.webContents.setZoomFactor(Math.min(currentZoom + 0.1, 3.0));
          }
        },
        {
          label: 'Сбросить масштаб',
          accelerator: 'CmdOrCtrl+0',
          click: () => mainWindow.webContents.setZoomFactor(1.0)
        }
      ]
    },
    {
      label: 'Инструменты',
      submenu: [
        {
          label: 'Консоль разработчика',
          accelerator: process.platform === 'darwin' ? 'Alt+Cmd+I' : 'Ctrl+Shift+I',
          click: () => mainWindow.webContents.toggleDevTools()
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// События приложения
app.whenReady().then(() => {
  startServer();
  createMainWindow();
  createMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

// Обработка ошибок
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});