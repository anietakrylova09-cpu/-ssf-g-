import { 
  type User, 
  type InsertUser, 
  type OsintSearch, 
  type InsertOsintSearch,
  type AiConversation,
  type InsertAiConversation,
  type PhoneValidation,
  type InsertPhoneValidation
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // OSINT Search methods
  createOsintSearch(search: InsertOsintSearch): Promise<OsintSearch>;
  getOsintSearch(id: string): Promise<OsintSearch | undefined>;
  updateOsintSearch(id: string, updates: Partial<OsintSearch>): Promise<OsintSearch | undefined>;

  // AI Conversation methods
  createAiConversation(conversation: InsertAiConversation): Promise<AiConversation>;
  getAiConversation(id: string): Promise<AiConversation | undefined>;
  updateAiConversation(id: string, updates: Partial<AiConversation>): Promise<AiConversation | undefined>;

  // Phone Validation methods
  createPhoneValidation(validation: InsertPhoneValidation): Promise<PhoneValidation>;
  getPhoneValidation(phoneNumber: string): Promise<PhoneValidation | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private osintSearches: Map<string, OsintSearch>;
  private aiConversations: Map<string, AiConversation>;
  private phoneValidations: Map<string, PhoneValidation>;

  constructor() {
    this.users = new Map();
    this.osintSearches = new Map();
    this.aiConversations = new Map();
    this.phoneValidations = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createOsintSearch(insertSearch: InsertOsintSearch): Promise<OsintSearch> {
    const id = randomUUID();
    const search: OsintSearch = {
      ...insertSearch,
      id,
      userId: null,
      results: insertSearch.results || null,
      status: insertSearch.status || "pending",
      createdAt: new Date(),
    };
    this.osintSearches.set(id, search);
    return search;
  }

  async getOsintSearch(id: string): Promise<OsintSearch | undefined> {
    return this.osintSearches.get(id);
  }

  async updateOsintSearch(id: string, updates: Partial<OsintSearch>): Promise<OsintSearch | undefined> {
    const existing = this.osintSearches.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.osintSearches.set(id, updated);
    return updated;
  }

  async createAiConversation(insertConversation: InsertAiConversation): Promise<AiConversation> {
    const id = randomUUID();
    const conversation: AiConversation = {
      ...insertConversation,
      id,
      userId: null,
      messages: insertConversation.messages || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.aiConversations.set(id, conversation);
    return conversation;
  }

  async getAiConversation(id: string): Promise<AiConversation | undefined> {
    return this.aiConversations.get(id);
  }

  async updateAiConversation(id: string, updates: Partial<AiConversation>): Promise<AiConversation | undefined> {
    const existing = this.aiConversations.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates, updatedAt: new Date() };
    this.aiConversations.set(id, updated);
    return updated;
  }

  async createPhoneValidation(insertValidation: InsertPhoneValidation): Promise<PhoneValidation> {
    const id = randomUUID();
    const validation: PhoneValidation = {
      phoneNumber: insertValidation.phoneNumber,
      isValid: insertValidation.isValid,
      country: insertValidation.country || null,
      region: insertValidation.region || null,
      operator: insertValidation.operator || null,
      phoneType: insertValidation.phoneType || null,
      socialProfiles: insertValidation.socialProfiles || null,
      id,
      createdAt: new Date(),
    };
    this.phoneValidations.set(id, validation);
    return validation;
  }

  async getPhoneValidation(phoneNumber: string): Promise<PhoneValidation | undefined> {
    return Array.from(this.phoneValidations.values()).find(
      (validation) => validation.phoneNumber === phoneNumber,
    );
  }
}

export const storage = new MemStorage();
