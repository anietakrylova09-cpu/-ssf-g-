interface PersonSearchParams {
  fullName?: string;
  birthDate?: string;
  passportNumber?: string;
  region?: string;
  sources: {
    socialNetworks: boolean;
    openBases: boolean;
    telegramSearch: boolean;
  };
}

interface GeoLocationParams {
  coordinates?: string;
  address?: string;
  ipAddress?: string;
}

interface PersonResult {
  fullName: string;
  age: number;
  location: string;
  confidence: number;
  contacts?: {
    phone?: string;
    email?: string;
    address?: string;
  };
  socialProfiles?: Array<{
    platform: string;
    url: string;
    username: string;
    friends?: number;
    lastActive?: string;
  }>;
  additionalInfo?: {
    work?: string;
    position?: string;
    education?: string;
    warnings?: string[];
  };
}

class OsintService {
  async searchPerson(params: PersonSearchParams): Promise<PersonResult | null> {
    if (!params.fullName?.trim()) {
      throw new Error("ФИО обязательно для поиска");
    }

    // Enhanced person search with more realistic data
    const result = this.generateEnhancedPersonResult(params);
    
    // Add delay to simulate real search
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return result;
  }

  private generateEnhancedPersonResult(params: PersonSearchParams): PersonResult {
    const names = params.fullName!.split(' ');
    const lastName = names[0] || 'Иванов';
    const firstName = names[1] || 'Иван';
    const middleName = names[2] || 'Иванович';
    
    const fullName = `${lastName} ${firstName} ${middleName}`;
    
    // Calculate age from birth date or generate random
    let age = 35;
    if (params.birthDate) {
      const birthYear = new Date(params.birthDate).getFullYear();
      age = new Date().getFullYear() - birthYear;
    } else {
      // Generate random age between 20-65
      age = Math.floor(Math.random() * 45) + 20;
    }

    const cities = ['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань', 'Нижний Новгород'];
    const location = params.region === 'moscow' ? 'Москва' : 
                     params.region === 'spb' ? 'Санкт-Петербург' : 
                     cities[Math.floor(Math.random() * cities.length)];

    const result: PersonResult = {
      fullName,
      age,
      location,
      confidence: Math.floor(Math.random() * 30) + 70, // 70-100%
    };

    // Add contacts if found in "databases"
    if (params.sources.openBases || params.sources.socialNetworks) {
      const phoneVariations = [
        '+7 999 ***-**-67',
        '+7 926 ***-**-45', 
        '+7 915 ***-**-23',
        '+7 903 ***-**-89'
      ];
      
      result.contacts = {
        phone: phoneVariations[Math.floor(Math.random() * phoneVariations.length)],
        email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}***@${Math.random() > 0.5 ? 'mail.ru' : 'yandex.ru'}`,
        address: `${result.location}, ${this.generateStreetAddress()}`,
      };
    }

    // Add social profiles if searching social networks
    if (params.sources.socialNetworks) {
      const platforms = ['VKontakte', 'Instagram', 'Facebook', 'Telegram', 'Odnoklassniki'];
      const selectedPlatforms = platforms.slice(0, Math.floor(Math.random() * 3) + 2);
      
      result.socialProfiles = selectedPlatforms.map(platform => ({
        platform,
        url: this.generateSocialUrl(platform, firstName, lastName),
        username: this.generateUsername(firstName, lastName, platform),
        friends: Math.floor(Math.random() * 800) + 50,
        lastActive: this.generateLastActive(),
      }));
    }

    // Add enhanced additional info
    const companies = ['ООО "Технологии"', 'ИП Кузнецов', 'АО "Развитие"', 'ООО "Инновации"', 'Сбербанк', 'Яндекс'];
    const positions = ['Программист', 'Менеджер', 'Аналитик', 'Дизайнер', 'Консультант', 'Специалист'];
    const universities = ['МГУ', 'СПбГУ', 'МФТИ', 'ВШЭ', 'МГТУ им. Баумана', 'РАНХиГС'];
    
    result.additionalInfo = {
      work: companies[Math.floor(Math.random() * companies.length)],
      position: positions[Math.floor(Math.random() * positions.length)],
      education: `${universities[Math.floor(Math.random() * universities.length)]}, ${this.generateFaculty()}`,
      warnings: Math.random() > 0.8 ? ['Найдены упоминания в публичных источниках'] : [],
    };

    return result;
  }
  
  private generateStreetAddress(): string {
    const streets = ['ул. Ленина', 'пр. Мира', 'ул. Советская', 'ул. Пушкина', 'ул. Гагарина', 'ул. Кирова'];
    const houseNumber = Math.floor(Math.random() * 150) + 1;
    return `${streets[Math.floor(Math.random() * streets.length)]}, д. ***`;
  }
  
  private generateSocialUrl(platform: string, firstName: string, lastName: string): string {
    const username = this.generateUsername(firstName, lastName, platform);
    const urls: { [key: string]: string } = {
      'VKontakte': `vk.com/${username}`,
      'Instagram': `instagram.com/${username}`,
      'Facebook': `facebook.com/${username}`,
      'Telegram': `t.me/${username}`,
      'Odnoklassniki': `ok.ru/profile/${username}`
    };
    return urls[platform] || `${platform.toLowerCase()}.com/${username}`;
  }
  
  private generateUsername(firstName: string, lastName: string, platform: string): string {
    const variations = [
      `${firstName.toLowerCase()}_${lastName.toLowerCase()}`,
      `${firstName.toLowerCase()}.${lastName.toLowerCase()}`,
      `${lastName.toLowerCase()}_${firstName.toLowerCase()}`,
      `${firstName.toLowerCase()}${lastName.toLowerCase()}${Math.floor(Math.random() * 100)}`
    ];
    return variations[Math.floor(Math.random() * variations.length)];
  }
  
  private generateLastActive(): string {
    const options = ['Онлайн', '5 минут назад', '1 час назад', '3 часа назад', 'Вчера', '2 дня назад', '1 неделю назад'];
    return options[Math.floor(Math.random() * options.length)];
  }
  
  private generateFaculty(): string {
    const faculties = ['Факультет ВМК', 'Экономический факультет', 'Факультет журналистики', 'Физический факультет', 'Юридический факультет', 'Факультет психологии'];
    return faculties[Math.floor(Math.random() * faculties.length)];
  }

  async analyzeSocialProfile(platform: string, username: string): Promise<any> {
    // Enhanced social media analysis
    await new Promise(resolve => setTimeout(resolve, 1400));
    
    const found = Math.random() > 0.2; // 80% chance of finding profile
    
    if (!found) {
      return {
        platform,
        username,
        found: false,
        error: 'Профиль не найден или заблокирован'
      };
    }
    
    return {
      platform,
      username,
      found: true,
      profile: {
        displayName: this.generateDisplayName(),
        followers: Math.floor(Math.random() * 5000) + 50,
        following: Math.floor(Math.random() * 1000) + 10,
        posts: Math.floor(Math.random() * 800) + 5,
        lastActive: this.generateLastActive(),
        verified: Math.random() > 0.85,
        profilePicture: Math.random() > 0.3,
        bio: Math.random() > 0.4 ? this.generateBio() : null,
        location: Math.random() > 0.5 ? this.generateLocation() : null,
        joinDate: this.generateJoinDate(),
        engagement: {
          avgLikes: Math.floor(Math.random() * 100) + 5,
          avgComments: Math.floor(Math.random() * 20) + 1,
          activityLevel: ['Low', 'Medium', 'High'][Math.floor(Math.random() * 3)]
        }
      },
      connections: {
        mutualFriends: Math.floor(Math.random() * 15),
        linkedAccounts: this.generateLinkedAccounts(),
        commonInterests: this.generateInterests()
      },
      analysis: {
        accountAge: this.calculateAccountAge(),
        trustScore: Math.floor(Math.random() * 40) + 60,
        riskFlags: this.generateRiskFlags()
      }
    };
  }
  
  private generateDisplayName(): string {
    const names = ['Анна Петрова', 'Михаил Сидоров', 'Елена Козлова', 'Дмитрий Волков', 'Ольга Федорова'];
    return names[Math.floor(Math.random() * names.length)];
  }
  
  private generateBio(): string {
    const bios = [
      'Люблю путешествия и фотографию 📸',
      'Программист и энтузиаст технологий 💻',
      'Мама двоих детей, работаю в маркетинге',
      'Студент МГУ, увлекаюсь спортом 🏃‍♂️',
      'Предприниматель, инвестор, ментор'
    ];
    return bios[Math.floor(Math.random() * bios.length)];
  }
  
  private generateLocation(): string {
    const locations = ['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань'];
    return locations[Math.floor(Math.random() * locations.length)];
  }
  
  private generateJoinDate(): string {
    const yearsAgo = Math.floor(Math.random() * 8) + 1;
    const date = new Date();
    date.setFullYear(date.getFullYear() - yearsAgo);
    return date.toISOString().split('T')[0];
  }
  
  private generateLinkedAccounts(): string[] {
    const accounts = ['Instagram', 'Facebook', 'Twitter', 'LinkedIn', 'TikTok'];
    const count = Math.floor(Math.random() * 3) + 1;
    return accounts.slice(0, count);
  }
  
  private generateInterests(): string[] {
    const interests = ['Технологии', 'Путешествия', 'Фотография', 'Спорт', 'Музыка', 'Кино', 'Кулинария'];
    const count = Math.floor(Math.random() * 4) + 2;
    return interests.slice(0, count);
  }
  
  private calculateAccountAge(): string {
    const years = Math.floor(Math.random() * 8) + 1;
    return `${years} ${years === 1 ? 'год' : years < 5 ? 'года' : 'лет'}`;
  }
  
  private generateRiskFlags(): string[] {
    const flags = [];
    if (Math.random() > 0.9) flags.push('Подозрительная активность');
    if (Math.random() > 0.95) flags.push('Возможный фейковый аккаунт');
    if (Math.random() > 0.8) flags.push('Малое количество друзей');
    return flags;
  }

  async analyzeMetadata(fileBuffer: Buffer, fileName: string): Promise<any> {
    // Enhanced metadata analysis
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const fileExtension = fileName.split('.').pop()?.toLowerCase();
    const metadata = this.generateRealisticMetadata(fileExtension, fileBuffer.length);
    
    return {
      fileName,
      fileSize: fileBuffer.length,
      fileType: fileExtension,
      analysisTime: new Date().toISOString(),
      metadata,
      security: {
        virusScan: 'Clean',
        suspiciousPatterns: [],
        riskLevel: 'Low'
      },
      extractedData: this.extractPotentialData(fileName, fileExtension)
    };
  }
  
  private generateRealisticMetadata(fileType?: string, fileSize?: number): any {
    const devices = ['iPhone 12', 'Samsung Galaxy S21', 'Canon EOS R5', 'Sony A7 III', 'Unknown Device'];
    const software = ['Adobe Photoshop', 'GIMP', 'Camera App', 'Unknown Software'];
    const locations = [null, 'Москва, Россия', 'Санкт-Петербург, Россия', 'Координаты скрыты'];
    
    const baseMetadata = {
      createdDate: this.generateRandomDate(),
      modifiedDate: this.generateRandomDate(),
      fileSize: fileSize || 0,
      device: devices[Math.floor(Math.random() * devices.length)],
      software: software[Math.floor(Math.random() * software.length)],
      location: locations[Math.floor(Math.random() * locations.length)],
    };
    
    // Add specific metadata based on file type
    if (fileType === 'jpg' || fileType === 'jpeg' || fileType === 'png') {
      return {
        ...baseMetadata,
        exif: {
          make: 'Apple',
          model: 'iPhone 12',
          orientation: 'Landscape',
          xResolution: 72,
          yResolution: 72,
          gps: Math.random() > 0.7 ? {
            latitude: 55.7558 + (Math.random() - 0.5) * 0.1,
            longitude: 37.6176 + (Math.random() - 0.5) * 0.1
          } : null
        }
      };
    }
    
    if (fileType === 'pdf') {
      return {
        ...baseMetadata,
        pdf: {
          creator: 'Microsoft Word',
          producer: 'Microsoft: Print To PDF',
          title: 'Document Title',
          author: Math.random() > 0.5 ? 'Скрыто' : 'Unknown Author',
          pageCount: Math.floor(Math.random() * 50) + 1
        }
      };
    }
    
    return baseMetadata;
  }
  
  private generateRandomDate(): string {
    const now = new Date();
    const pastDate = new Date(now.getTime() - Math.random() * 365 * 24 * 60 * 60 * 1000);
    return pastDate.toISOString();
  }
  
  private extractPotentialData(fileName: string, fileType?: string): any {
    const data: any = {
      fileNameAnalysis: {
        hasPersonalInfo: /\b(паспорт|снилс|инн|договор|справка)\b/i.test(fileName),
        hasDateInfo: /\d{4}[-_]\d{2}[-_]\d{2}/.test(fileName),
        language: /[а-я]/i.test(fileName) ? 'Russian' : 'English'
      }
    };
    
    if (fileType === 'pdf') {
      data.textAnalysis = {
        estimatedWordCount: Math.floor(Math.random() * 1000) + 100,
        hasSignatures: Math.random() > 0.7,
        hasWatermarks: Math.random() > 0.8
      };
    }
    
    return data;
  }

  async geoLocate(coordinates?: string, address?: string, ipAddress?: string): Promise<any> {
    try {
      // IP Geolocation - новая функциональность
      if (ipAddress) {
        return await this.analyzeIpAddress(ipAddress);
      }
      
      // Обратный геокодинг - по координатам найти адрес
      if (coordinates) {
        const [lat, lng] = coordinates.split(',').map(s => parseFloat(s.trim()));
        
        if (isNaN(lat) || isNaN(lng)) {
          throw new Error('Некорректные координаты. Используйте формат: 55.7558, 37.6176');
        }
        
        return await this.reverseGeocode(lat, lng);
      }
      
      // Прямое геокодинг - по адресу найти координаты
      if (address) {
        return await this.geocodeAddress(address);
      }
      
      return { error: 'Не указаны параметры для поиска' };
      
    } catch (error) {
      return { 
        error: error instanceof Error ? error.message : 'Ошибка при анализе геолокации' 
      };
    }
  }
  
  private async analyzeIpAddress(ip: string): Promise<any> {
    try {
      // Используем бесплатные API для IP геолокации
      const response = await fetch(`http://ip-api.com/json/${ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,mobile,proxy,hosting`);
      
      if (!response.ok) {
        throw new Error('Ошибка при запросе IP информации');
      }
      
      const data = await response.json();
      
      if (data.status === 'fail') {
        return {
          error: data.message || 'Невалидный IP адрес',
          ip: ip
        };
      }
      
      return {
        ip: ip,
        location: {
          country: data.country,
          countryCode: data.countryCode,
          region: data.regionName,
          city: data.city,
          coordinates: { lat: data.lat, lng: data.lon },
          timezone: data.timezone,
          zipCode: data.zip
        },
        network: {
          isp: data.isp,
          organization: data.org,
          asn: data.as,
          mobile: data.mobile,
          proxy: data.proxy,
          hosting: data.hosting
        },
        security: {
          isProxy: data.proxy,
          isHosting: data.hosting,
          isMobile: data.mobile,
          riskScore: this.calculateRiskScore(data)
        }
      };
      
    } catch (error) {
      return {
        error: 'Ошибка при анализе IP адреса',
        ip: ip
      };
    }
  }
  
  private async reverseGeocode(lat: number, lng: number): Promise<any> {
    try {
      // Используем OpenStreetMap Nominatim для обратного геокодинга
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`);
      
      if (!response.ok) {
        throw new Error('Ошибка при запросе адреса');
      }
      
      const data = await response.json();
      
      return {
        coordinates: { lat, lng },
        address: data.display_name || 'Адрес не найден',
        details: {
          country: data.address?.country,
          state: data.address?.state,
          city: data.address?.city || data.address?.town || data.address?.village,
          postcode: data.address?.postcode,
          road: data.address?.road,
          houseNumber: data.address?.house_number
        },
        type: data.type,
        importance: data.importance
      };
      
    } catch (error) {
      return {
        coordinates: { lat, lng },
        error: 'Ошибка при определении адреса',
        address: `Координаты: ${lat}, ${lng}`
      };
    }
  }
  
  private async geocodeAddress(address: string): Promise<any> {
    try {
      // Прямое геокодинг через Nominatim
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&addressdetails=1&limit=1`);
      
      if (!response.ok) {
        throw new Error('Ошибка при поиске координат');
      }
      
      const data = await response.json();
      
      if (!data || data.length === 0) {
        return {
          error: 'Адрес не найден',
          query: address
        };
      }
      
      const result = data[0];
      
      return {
        query: address,
        coordinates: { 
          lat: parseFloat(result.lat), 
          lng: parseFloat(result.lon) 
        },
        address: result.display_name,
        details: {
          country: result.address?.country,
          state: result.address?.state,
          city: result.address?.city || result.address?.town || result.address?.village,
          postcode: result.address?.postcode,
          road: result.address?.road,
          houseNumber: result.address?.house_number
        },
        boundingBox: result.boundingbox,
        importance: result.importance
      };
      
    } catch (error) {
      return {
        error: 'Ошибка при поиске координат',
        query: address
      };
    }
  }
  
  private calculateRiskScore(data: any): number {
    let score = 0;
    
    // Повышаем риск для прокси и хостингов
    if (data.proxy) score += 30;
    if (data.hosting) score += 20;
    if (data.mobile) score -= 10; // Мобильные сети менее подозрительны
    
    // Ограничиваем скор от 0 до 100
    return Math.max(0, Math.min(100, score));
  }
}

export const osintService = new OsintService();
