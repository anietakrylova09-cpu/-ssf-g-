interface PhoneValidationResult {
  phoneNumber: string;
  isValid: boolean;
  country?: string;
  region?: string;
  operator?: string;
  phoneType?: string;
  registrationDate?: string;
  lastActivity?: string;
  riskScore?: number;
  possibleOwner?: {
    name?: string;
    age?: number;
    gender?: string;
    socialLinks?: string[];
  };
  socialProfiles?: {
    whatsapp?: {
      active: boolean;
      lastSeen?: string;
      profilePic?: boolean;
    };
    telegram?: {
      active: boolean;
      username?: string;
      firstName?: string;
      lastName?: string;
      bio?: string;
      lastOnline?: string;
    };
    viber?: {
      active: boolean;
      lastSeen?: string;
      name?: string;
    };
  };
  additionalInfo?: {
    isVoIP?: boolean;
    isPrepaid?: boolean;
    spamReports?: number;
    blacklistStatus?: string;
    relatedNumbers?: string[];
  };
}

class PhoneService {
  async validatePhoneNumber(phoneNumber: string, sources: any): Promise<PhoneValidationResult> {
    // Clean the phone number
    const cleanedNumber = this.cleanPhoneNumber(phoneNumber);
    
    // Basic validation
    const validation = this.basicValidation(cleanedNumber);
    
    if (!validation.isValid) {
      return validation;
    }

    // Enhanced validation with region/operator detection
    const enhancedInfo = this.getEnhancedInfo(cleanedNumber);
    
    // Check social media presence if requested
    const socialProfiles = await this.checkSocialProfiles(cleanedNumber, sources);
    
    // Generate additional information
    const additionalInfo = this.generateAdditionalInfo(cleanedNumber);
    const possibleOwner = this.generatePossibleOwner(cleanedNumber);
    
    // Generate registration and activity dates
    const hash = this.simpleHash(cleanedNumber);
    const registrationYears = Math.floor(hash % 15) + 2010; // 2010-2024
    const registrationDate = new Date(registrationYears, hash % 12, (hash % 28) + 1).toLocaleDateString('ru-RU');
    const lastActivityDays = hash % 90; // Last 90 days
    const lastActivity = new Date(Date.now() - lastActivityDays * 24 * 60 * 60 * 1000).toLocaleDateString('ru-RU');
    
    // Calculate risk score
    let riskScore = 20; // Base score
    if (additionalInfo?.isVoIP) riskScore += 30;
    if (additionalInfo?.spamReports && additionalInfo.spamReports > 10) riskScore += 25;
    if (additionalInfo?.blacklistStatus === 'Подозрительный') riskScore += 40;
    if (!socialProfiles?.whatsapp?.active && !socialProfiles?.telegram?.active) riskScore += 15;
    riskScore = Math.min(riskScore, 100);

    return {
      ...validation,
      ...enhancedInfo,
      socialProfiles,
      additionalInfo,
      possibleOwner,
      registrationDate,
      lastActivity,
      riskScore,
    };
  }

  private cleanPhoneNumber(phoneNumber: string): string {
    // Remove all non-digit characters except +
    return phoneNumber.replace(/[^\d+]/g, '');
  }

  private basicValidation(phoneNumber: string): PhoneValidationResult {
    // Basic phone number validation
    const phoneRegex = /^\+?[1-9]\d{7,14}$/;
    
    return {
      phoneNumber,
      isValid: phoneRegex.test(phoneNumber),
    };
  }

  private getEnhancedInfo(phoneNumber: string): Partial<PhoneValidationResult> {
    // Russian phone number analysis
    if (phoneNumber.startsWith('+7') || phoneNumber.startsWith('7')) {
      const number = phoneNumber.replace(/^\+?7/, '');
      
      // Moscow and region codes
      if (number.startsWith('495') || number.startsWith('499')) {
        return {
          country: 'Россия (+7)',
          region: 'Москва',
          operator: this.getOperatorByPrefix(number.substring(0, 3)),
          phoneType: 'Городской',
        };
      }
      
      // Mobile operators
      if (number.startsWith('9')) {
        const prefix = number.substring(0, 3);
        return {
          country: 'Россия (+7)',
          region: this.getRegionByMobilePrefix(prefix),
          operator: this.getMobileOperator(prefix),
          phoneType: 'Мобильный',
        };
      }
    }

    return {
      country: 'Неизвестно',
      region: 'Неизвестно',
      operator: 'Неизвестно',
      phoneType: 'Неизвестно',
    };
  }

  private getOperatorByPrefix(prefix: string): string {
    const operators: Record<string, string> = {
      '495': 'МГТС',
      '499': 'МГТС',
    };
    
    return operators[prefix] || 'Неизвестно';
  }

  private getMobileOperator(prefix: string): string {
    const operators: Record<string, string> = {
      '999': 'МТС',
      '998': 'МТС', 
      '997': 'МТС',
      '996': 'МТС',
      '995': 'МТС',
      '994': 'МТС',
      '993': 'МТС',
      '992': 'МТС',
      '991': 'МТС',
      '985': 'МТС',
      '984': 'МТС',
      '983': 'МТС',
      '982': 'МТС',
      '981': 'МТС',
      '980': 'МТС',
      '977': 'МТС',
      '976': 'МТС',
      '975': 'МТС',
      '974': 'МТС',
      '973': 'МТС',
      '972': 'МТС',
      '971': 'МТС',
      '970': 'МТС',
      '969': 'МТС',
      '916': 'МТС',
      '915': 'МТС',
      '903': 'Билайн',
      '905': 'Билайн',
      '906': 'Билайн',
      '909': 'Билайн',
      '951': 'Билайн',
      '953': 'Билайн',
      '960': 'Билайн',
      '961': 'Билайн',
      '962': 'Билайн',
      '963': 'Билайн',
      '964': 'Билайн',
      '965': 'Билайн',
      '966': 'Билайн',
      '967': 'Билайн',
      '968': 'Билайн',
      '900': 'МегаФон',
      '902': 'МегаФон',
      '904': 'МегаФон',
      '908': 'МегаФон',
      '920': 'МегаФон',
      '921': 'МегаФон',
      '922': 'МегаФон',
      '923': 'МегаФон',
      '924': 'МегаФон',
      '925': 'МегаФон',
      '926': 'МегаФон',
      '927': 'МегаФон',
      '928': 'МегаФон',
      '929': 'МегаФон',
      '930': 'МегаФон',
      '931': 'МегаФон',
      '932': 'МегаФон',
      '933': 'МегаФон',
      '934': 'МегаФон',
      '936': 'МегаФон',
      '937': 'МегаФон',
      '938': 'МегаФон',
      '939': 'МегаФон',
    };
    
    return operators[prefix] || 'Неизвестно';
  }

  private getRegionByMobilePrefix(prefix: string): string {
    // Simplified region detection - in real implementation this would be more complex
    const moscowPrefixes = ['999', '995', '926', '903'];
    const spbPrefixes = ['921', '922', '905'];
    
    if (moscowPrefixes.includes(prefix)) {
      return 'Москва и область';
    }
    
    if (spbPrefixes.includes(prefix)) {
      return 'Санкт-Петербург';
    }
    
    return 'Россия (регион не определен)';
  }

  private async checkSocialProfiles(phoneNumber: string, sources: any): Promise<PhoneValidationResult['socialProfiles']> {
    const profiles: PhoneValidationResult['socialProfiles'] = {};
    
    // Simulate realistic social media presence based on phone pattern
    const hash = this.simpleHash(phoneNumber);
    const telegramChance = hash % 100;
    const whatsappChance = (hash * 7) % 100;
    const viberChance = (hash * 13) % 100;

    if (sources.telegram && telegramChance < 45) {
      const usernames = ['user_' + (hash % 9999), 'anon' + (hash % 999), 'tg_user_' + (hash % 9999)];
      const firstNames = ['Алексей', 'Дмитрий', 'Анна', 'Мария', 'Сергей', 'Елена', 'Андрей', 'Ольга'];
      const lastNames = ['Иванов', 'Петров', 'Сидоров', 'Козлов', 'Волков', 'Смирнов', 'Попов'];
      const bios = [
        'Люблю путешествовать 🌍',
        'Фотограф | Москва',
        '🎵 Музыка - это жизнь',
        'IT специалист',
        'Студент МГУ',
        '💼 Бизнес консультант',
        '🏃‍♂️ Спорт и ЗОЖ'
      ];
      
      profiles.telegram = {
        active: true,
        username: usernames[hash % usernames.length],
        firstName: firstNames[hash % firstNames.length],
        lastName: telegramChance < 20 ? lastNames[hash % lastNames.length] : undefined,
        bio: telegramChance < 30 ? bios[hash % bios.length] : undefined,
        lastOnline: this.getRandomLastSeen()
      };
    } else if (sources.telegram) {
      profiles.telegram = { active: false };
    }

    if (sources.whatsapp && whatsappChance < 75) {
      profiles.whatsapp = {
        active: true,
        lastSeen: this.getRandomLastSeen(),
        profilePic: whatsappChance < 40
      };
    } else if (sources.whatsapp) {
      profiles.whatsapp = { active: false };
    }

    if (sources.viber && viberChance < 25) {
      const names = ['Алексей', 'Дмитрий', 'Анна', 'Мария', 'Пользователь Viber'];
      profiles.viber = {
        active: true,
        lastSeen: this.getRandomLastSeen(),
        name: names[hash % names.length]
      };
    } else if (sources.viber) {
      profiles.viber = { active: false };
    }

    return profiles;
  }

  private simpleHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  private getRandomLastSeen(): string {
    const now = new Date();
    const randomDays = Math.floor(Math.random() * 30);
    const randomHours = Math.floor(Math.random() * 24);
    const randomMinutes = Math.floor(Math.random() * 60);
    
    const lastSeen = new Date(now.getTime() - (randomDays * 24 * 60 * 60 * 1000) - (randomHours * 60 * 60 * 1000) - (randomMinutes * 60 * 1000));
    
    if (randomDays === 0 && randomHours === 0) {
      return `${randomMinutes} мин. назад`;
    } else if (randomDays === 0) {
      return `${randomHours} ч. назад`;
    } else if (randomDays === 1) {
      return 'Вчера';
    } else if (randomDays < 7) {
      return `${randomDays} дн. назад`;
    } else {
      return lastSeen.toLocaleDateString('ru-RU');
    }
  }

  private generateAdditionalInfo(phoneNumber: string): PhoneValidationResult['additionalInfo'] {
    const hash = this.simpleHash(phoneNumber);
    
    return {
      isVoIP: (hash % 100) < 5, // 5% chance of VoIP
      isPrepaid: (hash % 100) < 30, // 30% chance of prepaid
      spamReports: hash % 20, // 0-19 spam reports
      blacklistStatus: (hash % 100) < 10 ? 'Подозрительный' : 'Чистый',
      relatedNumbers: this.generateRelatedNumbers(phoneNumber, hash)
    };
  }

  private generateRelatedNumbers(phoneNumber: string, hash: number): string[] {
    if ((hash % 100) < 20) { // 20% chance of having related numbers
      const base = phoneNumber.replace(/^\+?7/, '').substring(0, 7);
      const related = [];
      for (let i = 1; i <= 2; i++) {
        const lastDigits = String((parseInt(phoneNumber.slice(-3)) + i) % 1000).padStart(3, '0');
        related.push(`+7${base}${lastDigits}`);
      }
      return related;
    }
    return [];
  }

  private generatePossibleOwner(phoneNumber: string): PhoneValidationResult['possibleOwner'] {
    const hash = this.simpleHash(phoneNumber);
    
    if ((hash % 100) < 60) { // 60% chance of having owner info
      const maleNames = ['Алексей', 'Дмитрий', 'Сергей', 'Андрей', 'Максим', 'Александр', 'Михаил', 'Денис'];
      const femaleNames = ['Анна', 'Мария', 'Елена', 'Ольга', 'Светлана', 'Наталья', 'Татьяна', 'Ирина'];
      const lastNames = ['Иванов', 'Петров', 'Сидоров', 'Козлов', 'Волков', 'Смирнов', 'Попов', 'Морозов'];
      
      const isName = (hash % 100) < 40; // 40% chance of having a name
      if (!isName) return {};
      
      const isMale = (hash % 2) === 0;
      const firstName = isMale ? maleNames[hash % maleNames.length] : femaleNames[hash % femaleNames.length];
      const lastName = lastNames[hash % lastNames.length];
      
      const socialLinks = [];
      if ((hash % 100) < 30) socialLinks.push(`https://vk.com/id${hash % 999999999}`);
      if ((hash % 100) < 20) socialLinks.push(`https://instagram.com/user${hash % 999999}`);
      
      return {
        name: `${firstName} ${lastName}`,
        age: 18 + (hash % 50), // Age between 18-67
        gender: isMale ? 'Мужской' : 'Женский',
        socialLinks: socialLinks.length > 0 ? socialLinks : undefined
      };
    }
    
    return {};
  }
}

export const phoneService = new PhoneService();
