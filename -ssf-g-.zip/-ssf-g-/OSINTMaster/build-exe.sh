#!/bin/bash

# OSINT Platform - Build .exe script
echo "🔍 OSINT Platform - Сборка .exe версии"
echo "======================================="

# Проверка зависимостей
echo "📦 Проверка зависимостей..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не найден. Установите Node.js."
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "❌ npm не найден. Установите npm."
    exit 1
fi

# Проверка package.json
if [ ! -f "package.json" ]; then
    echo "❌ package.json не найден. Запустите скрипт из корневой директории проекта."
    exit 1
fi

# Создание структуры папок
echo "📁 Создание структуры папок..."
mkdir -p dist-electron
mkdir -p electron/assets

# Проверка установки electron-builder
echo "🔧 Проверка electron-builder..."
if ! npm list electron-builder &> /dev/null; then
    echo "⚠️  electron-builder не найден. Устанавливаем..."
    npm install --save-dev electron-builder
fi

# Сборка фронтенда
echo "🏗️  Сборка фронтенда..."
if ! npm run build; then
    echo "❌ Ошибка при сборке фронтенда"
    exit 1
fi

echo "✅ Фронтенд собран успешно"

# Проверка сборки сервера
echo "🖥️  Проверка сборки сервера..."
if [ ! -d "dist" ]; then
    echo "❌ Директория dist не найдена. Проверьте сборку."
    exit 1
fi

# Копирование файлов
echo "📋 Копирование файлов конфигурации..."
cp electron-builder.config.js ./
if [ -f "installer.nsh" ]; then
    cp installer.nsh ./
fi

# Создание временного package.json для electron
echo "📄 Подготовка конфигурации для Electron..."
cat > temp-package.json << EOF
{
  "name": "osint-platform",
  "version": "1.0.0",
  "description": "Комплексная нейро-OSINT платформа с двумя ИИ",
  "main": "electron/main.js",
  "author": "OSINT Platform Team",
  "license": "MIT",
  "scripts": {
    "electron": "electron .",
    "build-electron": "electron-builder --config electron-builder.config.js"
  }
}
EOF

# Резервное копирование оригинального package.json
if [ -f "package.json" ]; then
    cp package.json package.json.backup
    echo "📦 Создана резервная копия package.json"
fi

# Замена package.json для сборки
cp temp-package.json package.json

# Сборка .exe файла
echo "🔨 Сборка .exe файла..."
echo "Это может занять несколько минут..."

if npx electron-builder --config electron-builder.config.js --win --publish=never; then
    echo "✅ .exe файл успешно создан!"
    echo ""
    echo "📁 Результаты сборки:"
    if [ -d "dist-electron" ]; then
        ls -la dist-electron/
        echo ""
        echo "🎉 OSINT Platform .exe версия готова!"
        echo "📍 Найти файлы можно в папке: dist-electron/"
        echo ""
        echo "📋 Созданные файлы:"
        find dist-electron -name "*.exe" -o -name "*.msi" -o -name "*.zip" | head -10
    else
        echo "⚠️  Папка dist-electron не найдена"
    fi
else
    echo "❌ Ошибка при сборке .exe файла"
    echo "💡 Попробуйте запустить повторно или проверьте логи"
fi

# Восстановление оригинального package.json
if [ -f "package.json.backup" ]; then
    mv package.json.backup package.json
    echo "📦 Восстановлен оригинальный package.json"
fi

# Очистка временных файлов
rm -f temp-package.json

echo ""
echo "🔍 Сборка OSINT Platform завершена!"
echo "======================================="