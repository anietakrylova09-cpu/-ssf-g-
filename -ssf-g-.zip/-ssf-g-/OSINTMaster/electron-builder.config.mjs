export default {
  appId: 'com.amalya.app',
  productName: 'Amalya',
  directories: {
    output: 'dist-electron'
  },
  files: [
    'electron/**/*',
    'dist/**/*',
    'server/**/*', 
    'shared/**/*',
    'node_modules/**/*',
    {
      from: '.',
      filter: ['package.json']
    }
  ],
  extraMetadata: {
    main: 'electron/main.js'
  },
  win: {
    target: [
      {
        target: 'nsis',
        arch: ['x64', 'ia32']
      },
      {
        target: 'portable', 
        arch: ['x64', 'ia32']
      }
    ],
    publisherName: 'Amalya Team',
    verifyUpdateCodeSignature: false
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
    createDesktopShortcut: true,
    createStartMenuShortcut: true,
    shortcutName: 'Amalya',
    uninstallDisplayName: 'Amalya',
    deleteAppDataOnUninstall: true
  },
  portable: {
    artifactName: 'Amalya-Portable-${version}.${ext}'
  },
  linux: {
    target: [
      {
        target: 'AppImage',
        arch: ['x64']
      },
      {
        target: 'deb',
        arch: ['x64'] 
      }
    ],
    category: 'Utility'
  },
  mac: {
    target: [
      {
        target: 'dmg',
        arch: ['x64', 'arm64']
      }
    ],
    category: 'public.app-category.utilities'
  },
  dmg: {
    title: 'Amalya'
  },
  publish: null
};