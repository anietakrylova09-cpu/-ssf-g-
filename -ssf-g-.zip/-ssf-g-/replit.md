# OSINT Master

## Overview

OSINT Master is a comprehensive Open Source Intelligence platform that provides various investigative tools and AI-powered analysis capabilities. The application combines traditional OSINT techniques with modern AI services to assist in investigations involving phone numbers, people search, social media analysis, metadata extraction, and geographic tracking. It features a modular architecture supporting both web-based tools and external software integrations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and ES modules
- **Styling**: Tailwind CSS with shadcn/ui component library using "new-york" style
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Comprehensive Radix UI primitives with custom theming and CSS variables
- **Build Tool**: Vite for fast development with HMR and optimized production builds
- **Theme System**: Multi-theme support (pink, blue, green, purple) with CSS custom properties

### Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **Runtime**: ES modules with modern JavaScript features
- **Database ORM**: Drizzle ORM configured for PostgreSQL dialect
- **Data Storage**: Flexible storage abstraction with in-memory implementation (IStorage interface)
- **API Design**: RESTful endpoints with centralized error handling and request/response logging
- **Development Tools**: Runtime error overlay and request duration monitoring

### Core Services Architecture
- **AI Service**: Multi-provider AI integration supporting Grok (xAI) and DeepSeek APIs with health monitoring, retry logic, and timeout handling
- **Phone Service**: Phone number validation with carrier detection, region identification, and social media presence checking
- **OSINT Service**: Person search capabilities with configurable data sources and realistic result simulation
- **Softs Service**: External software integration platform for executing .exe tools with manifest-based configuration

### Database Schema Design
- **Users**: Authentication foundation with username/password model
- **OSINT Searches**: Search query tracking with type classification, results storage, and status monitoring
- **AI Conversations**: Chat history persistence with message arrays and timestamp tracking
- **Phone Validations**: Phone validation results with metadata and social profile information
- **Schema Validation**: Zod integration for type-safe API request/response validation

### External Software Integration
- **Softs Directory Structure**: Organized tool categories (probiv, snos) with manifest.json configuration
- **Tool Execution**: Sandboxed execution with timeout limits, argument templating, and result capturing
- **Upload System**: Dynamic software upload with automatic type detection and configuration
- **Security**: Restricted file system access and execution time limits

### Development Environment Features
- **Hot Module Replacement**: Vite dev server with React Fast Refresh
- **Error Handling**: Runtime error modal overlay for development debugging
- **Request Logging**: Comprehensive API request/response logging with duration tracking
- **Type Safety**: Full TypeScript coverage across client, server, and shared modules
- **Path Aliases**: Organized imports with @ prefixes for clean code organization

### Authentication & Session Management
- **Session Infrastructure**: Prepared for connect-pg-simple session storage
- **User Management**: Basic user model with extensible authentication system
- **Request Context**: User identification for personalized search history and results

### Performance Optimizations
- **Query Caching**: TanStack Query with infinite stale time for optimal caching
- **Bundle Optimization**: Vite build system with code splitting and asset optimization
- **Font Loading**: Preloaded Google Fonts with fallbacks
- **CSS Architecture**: Utility-first Tailwind with component-level customization

### Desktop Application Support
- **Electron Integration**: Cross-platform desktop application with Electron Builder
- **Multi-Architecture**: Support for x64 and ia32 architectures on Windows
- **Installer Configuration**: NSIS installer with desktop shortcuts and uninstall options
- **Development Mode**: Conditional DevTools and development server integration