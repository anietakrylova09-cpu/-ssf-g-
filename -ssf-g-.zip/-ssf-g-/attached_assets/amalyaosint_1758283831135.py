#!/usr/bin/env python3
# amalya_osint_helper.py
auth = ("rg3u13", "1dayKey_Wasted")
#привет всем кто смог декоднуть! красавчики люти уф сигма бой!!
import smtplib, threading, fake_useragent, string, random, webbrowser, requests, time, os, socket 
from faker import Faker
from email.mime.text import MIMEText
from pystyle import Colorate, Colors, Center, Write
import phonenumbers
from typing import Dict, Any, Optional
from phonenumbers import geocoder, carrier, timezone
from colorama import Fore, Style
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urlparse

a=input("Введи текстовый пароль для запуска программы:")
if a!="Амалия":
	print(colored(f"Пароль не верен! иди нахуй! ", 'red'))
	print(colored(f"Уточни его у создателя", 'red'))
	exit()

fake = Faker('ru_RU')

start_time = time.time()
function_count = 0
current_language = "ru"
current_theme = "white_to_black"
settings_file = "wasted_settings.json"

# Load settings
def load_settings():
    global current_theme, current_language
    if os.path.exists(settings_file):
        with open(settings_file, 'r', encoding='utf-8') as f:
            settings = json.load(f)
            current_theme = settings.get("theme", "red_to_yellow")
            current_language = settings.get("language", "ru")

# Save settings
def save_settings():
    settings = {"theme": current_theme, "language": current_language}
    with open(settings_file, 'w', encoding='utf-8') as f:
        json.dump(settings, f)

load_settings()

# Open Telegram links on startup

def open_telegram_links():
    try:
        webbrowser.open("https://t.me/adapetamaly", new=2)  # new=2 -> open in a new tab, if possible
        webbrowser.open("https://t.me/+SomlRV-0sr0wNTEy", new=2)
    except Exception:
        pass

open_telegram_links()

"""
AMALYA — Legal OSINT helper (educational).
Generates many search links/dorks from user-provided attributes (nick, name, year, city, phone)
and provides an OSINT resources manual. DOES NOT scrape or probe — only builds URLs for manual review.
"""

import csv
import sys
import urllib.parse
import webbrowser
from datetime import datetime

APP_NAME = "AMALYA"
CSV_FIELDS = ["label","category","engine","url","created_at"]

# Basic search engine templates
SEARCH_ENGINES = {
    "google": "https://www.google.com/search?q={q}",
    "bing": "https://www.bing.com/search?q={q}",
    "duckduckgo": "https://duckduckgo.com/?q={q}",
}

# Common site: templates for social networks and public sources
SITE_TEMPLATES = {
    "vk": "site:vk.com {q}",
    "ok": "site:ok.ru {q}",
    "instagram": "site:instagram.com {q}",
    "telegram": "site:t.me {q}",
    "twitter": "site:twitter.com {q}",
    "facebook": "site:facebook.com {q}",
    "youtube": "site:youtube.com {q}",
    "github": "site:github.com {q}",
    "linkedin": "site:linkedin.com {q}",
    "vk_public": "site:vk.com/public {q}",
    "whois": "whois {q}",
    "search_engines": "{q}"  # placeholder for direct engine queries
}

def banner():
    print("\n" + "="*70)
    print(f"{APP_NAME:^70}")
    print("="*70 + "\n")

def encode(q: str) -> str:
    return urllib.parse.quote_plus(q)

def make_basic_variants(attributes: dict):
    """
    Build query variants from given attributes.
    attributes: dict with keys: nick, fullname, year, city, phone
    Returns list of (label, query, category)
    """
    qlist = []
    nick = attributes.get("nick") or ""
    fullname = attributes.get("fullname") or ""
    year = attributes.get("year") or ""
    city = attributes.get("city") or ""
    phone = attributes.get("phone") or ""

    # Basic raw queries
    if nick:
        qlist.append(("nick_exact", f'"{nick}"', "nick"))
        qlist.append(("nick_intext", f'intext:"{nick}"', "nick"))
        qlist.append(("nick_socials", f'"{nick}" + (vk OR instagram OR telegram OR github)', "nick"))
    if fullname:
        qlist.append(("name_exact", f'"{fullname}"', "fullname"))
        qlist.append(("name_intitle", f'intitle:"{fullname}"', "fullname"))
        qlist.append(("name_intext", f'intext:"{fullname}"', "fullname"))
        qlist.append(("name_socials", f'"{fullname}" + (vk OR instagram OR facebook OR linkedin)', "fullname"))
    if fullname and year:
        qlist.append(("name_year", f'"{fullname}" "{year}"', "fullname"))
        qlist.append(("name_r_year", f'"{fullname}" "р. {year}"', "fullname"))
    if fullname and city:
        qlist.append(("name_city", f'"{fullname}" "{city}"', "fullname"))
    if phone:
        qlist.append(("phone_exact", f'"{phone}"', "phone"))
        digits = "".join(ch for ch in phone if ch.isdigit())
        if digits:
            qlist.append(("phone_digits", digits, "phone"))
            if len(digits) >= 10:
                qlist.append(("phone_local", digits[-10:], "phone"))
        qlist.append(("phone_socials", f'"{phone}" + (telegram OR vk OR viber OR whatsapp)', "phone"))

    # combinations
    if nick and city:
        qlist.append(("nick_city", f'"{nick}" "{city}"', "nick"))
    if fullname and nick:
        qlist.append(("name_nick", f'"{fullname}" "{nick}"', "mixed"))
    if fullname and phone:
        qlist.append(("name_phone", f'"{fullname}" "{phone}"', "mixed"))
    if fullname and city and year:
        qlist.append(("name_city_year", f'"{fullname}" "{city}" "{year}"', "mixed"))

    # More advanced dorks
    if fullname:
        qlist.append(("filetype_doc", f'"{fullname}" filetype:pdf OR filetype:doc OR filetype:docx', "dork"))
        qlist.append(("site_jobs", f'"{fullname}" (resume OR CV OR "резюме")', "dork"))
        qlist.append(("site_news", f'"{fullname}" (news OR "новости")', "dork"))

    return qlist

def build_links_from_queries(queries):
    """
    From list of (label, query, category) build full links for different search engines
    Returns list of dicts with url and metadata
    """
    links = []
    now = datetime.utcnow().isoformat()
    for label, query, category in queries:
        for engine_name, template in SEARCH_ENGINES.items():
            url = template.format(q=encode(query))
            links.append({
                "label": label,
                "category": category,
                "engine": engine_name,
                "url": url,
                "created_at": now
            })
    return links

def build_site_links_from_subject(subject):
    """
    Build site: specific searches using SITE_TEMPLATES
    """
    links = []
    now = datetime.utcnow().isoformat()
    for site_key, pattern in SITE_TEMPLATES.items():
        q = pattern.format(q=subject)
        # use google and duckduckgo for site searches
        for engine_name in ("google","duckduckgo"):
            template = SEARCH_ENGINES[engine_name]
            url = template.format(q=encode(q))
            links.append({
                "label": site_key,
                "category": f"site:{site_key}",
                "engine": engine_name,
                "url": url,
                "created_at": now
            })
    return links

def save_links_csv(links, filename="amalya_links.csv"):
    try:
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for it in links:
                writer.writerow({k: it.get(k,"") for k in CSV_FIELDS})
        print(f"[+] Saved {len(links)} links to {filename}")
    except Exception as e:
        print("[!] Error saving CSV:", e)

def print_links(links, limit=200):
    for i, it in enumerate(links,1):
        if i > limit:
            print(f"... ({len(links)-limit} more links hidden) ...")
            break
        print(f"[{i:03d}] {it['engine']:<8} {it['category']:<12} {it['url']}")

def open_links(links, count=10):
    n = min(len(links), count)
    if n == 0:
        print("[!] Нет ссылок для открытия.")
        return
    ans = input(f"Открыть первые {n} ссылок в браузере? (y/N): ").strip().lower()
    if ans == "y":
        for i in range(n):
            webbrowser.open(links[i]["url"])
        print(f"[+] Opened {n} links in default browser.")
    else:
        print("[-] Aborted opening links.")

def show_manual():
    manual = """
AMALYA OSINT — краткий мануал (этичный и легальный)
1) Используй только публичные данные. Не нарушай закон.
2) Всегда верифицируй информацию из >1 источника.
3) Источники, которые полезны:
   - Поисковые системы: Google, Bing, DuckDuckGo
   - Соцсети: VK, Instagram, Telegram, Facebook, Twitter/X, LinkedIn, GitHub, YouTube
   - Публичные реестры: компании, государственные базы, кадастр, суд. решения (в зависимости от страны)
   - Whois, DNS, архивы (Wayback Machine)
   - Специализированные агрегаторы: Google Maps, Yandex Maps, business registries
4) Храни результаты в CSV/JSON и защищай доступ.
5) При массовом мониторинге используй официальные API и соблюдай ToS.
6) Если задача чувствительная — работай через юридические каналы.
"""
    print(manual)

def main_loop():
    banner()
    print("Легальный OSINT-помощник — генерирует поисковые ссылки для ручной проверки.")
    # collect attributes
    nick = input("Ник (username) (ENTER чтобы пропустить): ").strip()
    fullname = input("ФИО / полное имя (ENTER чтобы пропустить): ").strip()
    year = input("Год рождения / возраст (опционально): ").strip()
    city = input("Город (опционально): ").strip()
    phone = input("Телефон (опционально): ").strip()

    attributes = {"nick": nick, "fullname": fullname, "year": year, "city": city, "phone": phone}

    queries = make_basic_variants(attributes)
    links = build_links_from_queries(queries)

    # site-specific queries for main identifiable subjects
    subject_for_sites = nick or fullname or phone or city
    if subject_for_sites:
        links += build_site_links_from_subject(subject_for_sites)

    # add some "public resource" starter searches if fullname present
    if fullname:
        extra = [
            ("fullname_resume", f'"{fullname}" resume OR CV OR "резюме"', "public_records"),
            ("fullname_news", f'"{fullname}" site:news.google.com OR site:ria.ru OR site:ln24.ru', "news"),
            ("fullname_wayback", f'filetype:html "{fullname}" site:web.archive.org', "archive"),
        ]
        links += build_links_from_queries(extra)

    print("\n[+] Generated links:")
    print_links(links, limit=200)

    # options
    while True:
        print("\nДоступные действия:")
        print("  [1] Сохранить ссылки в CSV")
        print("  [2] Открыть первые ссылки в браузере (по умолчанию 10)")
        print("  [3] Показать OSINT мануал")
        print("  [4] Сгенерировать дополнительные варианты для того же субъекта")
        print("  [0] Выход")
        choice = input("Выбор: ").strip()
        if choice == "1":
            fn = input("Имя CSV файла (ENTER = amalya_links.csv): ").strip() or "amalya_links.csv"
            save_links_csv(links, filename=fn)
        elif choice == "2":
            try:
                n = int(input("Сколько ссылок открыть? (ENTER = 10): ").strip() or "10")
            except Exception:
                n = 10
            open_links(links, count=n)
        elif choice == "3":
            show_manual()
        elif choice == "4":
            # create more aggressive variants (quotes, translit, email guesses)
            more = []
            if nick:
                more.append(("nick_translit", f'"{nick}" OR {nick.replace("_", " ")}', "nick"))
                more.append(("nick_intext_social", f'intext:"{nick}" (vk OR instagram OR t.me OR github)', "nick"))
            if fullname:
                # translit example: naive replacement cyrillic->latin not implemented; prompt user
                more.append(("name_variations", f'"{fullname}" OR "{fullname.replace(" ", "")}"', "fullname"))
                more.append(("name_email_guess", f'"{fullname.split()[0]}.{fullname.split()[-1]}" OR "{fullname.split()[-1]}{fullname.split()[0][0]}"', "fullname"))
            if phone:
                digits = "".join(ch for ch in phone if ch.isdigit())
                more.append(("phone_plus_variants", f'"{phone}" OR {digits}', "phone"))
            links += build_links_from_queries(more)
            print("[+] Added extra variants. Total links:", len(links))
        elif choice == "0":
            print("Выход. Используй результаты только легально и этично.")
            break
        else:
            print("Неверный ввод. Попробуй снова.")

if __name__ == "__main__":
    try:
        main_loop()
    except KeyboardInterrupt:
        print("\nПрервано пользователем. Пока.")
        sys.exit(0)
